package com.example.myapplication.component;

import com.example.myapplication.ResourceTable;

import ohos.agp.colors.RgbColor;
import ohos.agp.components.Component;
import ohos.agp.components.DependentLayout;
import ohos.agp.components.Image;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.TextField;
import ohos.agp.components.AttrSet;
import ohos.agp.components.element.ShapeElement;
import ohos.agp.utils.Color;
import ohos.app.Context;

/**
 * SearchBox
 */
public class SearchBox extends DependentLayout {
    private TextField inputText;

    private ClickedListener leftImageClickedListener;
    private ClickedListener rightImageClickedListener;

    public SearchBox(Context context) {
        super(context);
        initSearchBox();
    }

    public SearchBox(Context context, AttrSet attrSet) {
        super(context, attrSet);
        initSearchBox();
    }

    public SearchBox(Context context, AttrSet attrSet, String styleName) {
        super(context, attrSet, styleName);
        initSearchBox();
    }

    /**
     * set the initial background of the searchBox and bind the listener to the left and right images
     */
    private void initSearchBox() {
        Component searchBox = LayoutScatter.getInstance(
                getContext()).parse(ResourceTable.Layout_search_box, null, false);
        this.addComponent(searchBox);

        ShapeElement shapeElement = new ShapeElement();
        shapeElement.setShape(ShapeElement.RECTANGLE);
        shapeElement.setRgbColor(RgbColor.fromRgbaInt(Color.WHITE.getValue()));
        shapeElement.setCornerRadius(this.getHeight());
        this.setBackground(shapeElement);

        Image leftImage = (Image) searchBox.findComponentById(ResourceTable.Id_search_image);
        inputText = (TextField) searchBox.findComponentById(ResourceTable.Id_input_text);
        Image rightImage = (Image) searchBox.findComponentById(ResourceTable.Id_voice_image);

        leftImage.setClickedListener((Component component) -> {
            if (leftImageClickedListener != null) {
                leftImageClickedListener.onClick(component);
            }
        });

        rightImage.setClickedListener((Component component) -> {
            if (rightImageClickedListener != null) {
                rightImageClickedListener.onClick(component);
            }
        });
    }

    /**
     * set whether text can be entered in the searchBox
     *
     * @param enabled whether text can be entered in the searchBox
     */
    public void setEnabled(boolean enabled) {
        inputText.setEnabled(enabled);
    }

    /**
     * set searchBox hint
     *
     * @param hint hint
     */
    public void setHint(String hint) {
        inputText.setHint(hint);
    }

    /**
     * get searchBox input text
     *
     * @return searchBox input text
     */
    public String getInputText() {
        return inputText.getText();
    }

    /**
     * set searchBox background color
     *
     * @param backgroundColor searchBox background color
     */
    public void setBackgroundColor(RgbColor backgroundColor) {
        ShapeElement shapeElement = new ShapeElement();
        shapeElement.setShape(ShapeElement.RECTANGLE);
        shapeElement.setRgbColor(backgroundColor);
        shapeElement.setCornerRadius(this.getHeight());
        this.setBackground(shapeElement);
    }

    /**
     * set left image clicked listener
     *
     * @param leftImageClickedListener left image clicked listener
     */
    public void setLeftImageClickedListener(ClickedListener leftImageClickedListener) {
        this.leftImageClickedListener = leftImageClickedListener;
    }

    /**
     * set right image clicked listener
     *
     * @param rightImageClickedListener right image clicked listener
     */
    public void setRightImageClickedListener(ClickedListener rightImageClickedListener) {
        this.rightImageClickedListener = rightImageClickedListener;
    }
}
