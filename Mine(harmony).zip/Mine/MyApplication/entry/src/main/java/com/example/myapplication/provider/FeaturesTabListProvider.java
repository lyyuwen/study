package com.example.myapplication.provider;

import com.example.myapplication.ResourceTable;
import com.example.myapplication.component.GridContainer;
import com.example.myapplication.model.FeaturesTabItem;
import com.example.myapplication.model.GridItem;

import ohos.aafwk.ability.AbilitySlice;
import ohos.agp.components.BaseItemProvider;
import ohos.agp.components.Component;
import ohos.agp.components.ComponentContainer;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.TableLayout;
import ohos.agp.components.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * FeaturesTabListContainer item provider
 */
public class FeaturesTabListProvider extends BaseItemProvider {
    private static final int GRID_ITEM_MARGIN_BOTTOM = 12;
    private final List<FeaturesTabItem> featuresTabItemList;
    private final List<FeaturesTabListHolder> featuresTabListHolderList = new ArrayList<>();

    private AddClickedListener addClickedListener;

    /**
     * constructor, to prevent the featuresTabListContainer from stalling,
     * create each item in the featuresTabListContainer during initialization and cache the item
     *
     * @param slice               ability slice
     * @param featuresTabItemList featuresTabListItem list
     */
    public FeaturesTabListProvider(AbilitySlice slice, List<FeaturesTabItem> featuresTabItemList) {
        this.featuresTabItemList = featuresTabItemList;
        for (FeaturesTabItem featuresTabItem : featuresTabItemList) {
            Component featuresListItem = LayoutScatter.getInstance(slice)
                    .parse(ResourceTable.Layout_features_tab_item, null, false);
            FeaturesTabListHolder featuresTabListHolder = new FeaturesTabListHolder(featuresListItem);
            featuresTabListHolder.title.setText(featuresTabItem.getTitle());
            featuresTabListHolder.gridContainer.setItemMarginBottom(GRID_ITEM_MARGIN_BOTTOM);
            featuresTabListHolder.gridContainer.setGridItemList(featuresTabItem.getGridItemList());
            featuresTabListHolder.gridContainer.setAddClickedListener((GridItem gridItem) -> {
                if (addClickedListener != null) {
                    return addClickedListener.getAddItem(gridItem);
                }
                return false;
            });
            featuresTabListHolderList.add(featuresTabListHolder);
        }
    }

    @Override
    public int getCount() {
        return featuresTabItemList == null ? 0 : featuresTabItemList.size();
    }

    @Override
    public Object getItem(int position) {
        if (featuresTabItemList != null && position > 0 && position < featuresTabItemList.size()) {
            return featuresTabItemList.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Component getComponent(int position, Component component, ComponentContainer componentContainer) {
        return featuresTabListHolderList.get(position).component;
    }

    /**
     * Set featuresTabListContainer operate type, same as gridContainer
     *
     * @param operateType operate type
     */
    public void setOperateType(int operateType) {
        for (FeaturesTabListHolder featuresTabListHolder : featuresTabListHolderList) {
            featuresTabListHolder.gridContainer.setOperateType(operateType);
        }
    }

    /**
     * Update the operate type of gridItem in gridContainer
     *
     * @param gridItem    grid item
     * @param operateType operate type
     */
    public void updateGridContainer(GridItem gridItem, int operateType) {
        for (FeaturesTabListHolder featuresTabListHolder : featuresTabListHolderList) {
            if (featuresTabListHolder.gridContainer.containGridItem(gridItem) != -1) {
                featuresTabListHolder.gridContainer.setOperateType(operateType,
                        featuresTabListHolder.gridContainer.containGridItem(gridItem));
            }
        }
    }

    /**
     * Set add clicked listener
     *
     * @param addClickedListener add clicked listener
     */
    public void setAddClickedListener(AddClickedListener addClickedListener) {
        this.addClickedListener = addClickedListener;
    }

    /**
     * add clicked listener
     */
    public interface AddClickedListener {
        boolean getAddItem(GridItem gridItem);
    }

    /**
     * FeaturesTabListContainer view holder
     */
    public static class FeaturesTabListHolder {
        Text title;
        GridContainer gridContainer;
        Component component;

        FeaturesTabListHolder(Component component) {
            this.component = component;
            title = (Text) component.findComponentById(ResourceTable.Id_title);
            gridContainer = new GridContainer(
                    (TableLayout) component.findComponentById(ResourceTable.Id_grid_container));
        }
    }
}
