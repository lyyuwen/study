package com.example.myapplication.fraction;

import com.example.myapplication.ResourceTable;
import com.example.myapplication.component.ImagePageSliderCard;
import com.example.myapplication.component.LikeCard;
import com.example.myapplication.component.RecommendCard;
import com.example.myapplication.component.SearchBox;
import com.example.myapplication.component.GridContainer;
import com.example.myapplication.data.LifeFractionData;
import com.example.myapplication.model.GridItem;
import com.example.myapplication.slice.MoreAbilitySlice;

import com.example.myapplication.slice.WebAbilitySlice;

import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.ability.fraction.Fraction;
import ohos.aafwk.content.Intent;
import ohos.agp.colors.RgbColor;
import ohos.agp.components.Component;
import ohos.agp.components.ComponentContainer;
import ohos.agp.components.DirectionalLayout;
import ohos.agp.components.Image;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.ScrollView;
import ohos.agp.components.TableLayout;
import ohos.agp.components.Text;
import ohos.agp.components.element.ShapeElement;
import ohos.agp.utils.Color;


/**
 * Life Fraction display life page. All the data is in {@link LifeFractionData}.
 */
public class LifeFraction extends Fraction {
    private static final int PLAY_INTERVAL = 3000;
    private static final int ALPHA_MAX = 254;

    private final AbilitySlice slice;

    private Component lifeFraction;

    private DirectionalLayout searchBar;
    private SearchBox searchBox;
    private Text city;
    private Image pullDownImage;
    private Image serviceImage;

    public LifeFraction(AbilitySlice slice) {
        this.slice = slice;
    }

    @Override
    protected Component onComponentAttached(LayoutScatter scatter, ComponentContainer container, Intent intent) {
        lifeFraction = scatter.parse(ResourceTable.Layout_fraction_life, container, false);

        initScrollView();
        initTopImagePageSliderCard();
        initFeaturesContainer();
        initImagePageSliderCard();
        initRecommendCard();
        initLikeCard();
        initSearchBar();

        return lifeFraction;
    }

    private void initScrollView() {
        ScrollView scrollView = (ScrollView) lifeFraction.findComponentById(ResourceTable.Id_scroll_view);
        DirectionalLayout globalDirectionalLayout = (DirectionalLayout)
                lifeFraction.findComponentById(ResourceTable.Id_global_directional_layout);
        scrollView.setScrolledListener((Component component,
                                        int scrollX, int scrollY, int oldScrollX, int oldScrollY) ->
                updateSearchBarAlpha(-globalDirectionalLayout.getTop()));
    }

    private void initTopImagePageSliderCard() {
        ImagePageSliderCard topImagePageSliderCard = (ImagePageSliderCard) lifeFraction.findComponentById(
                ResourceTable.Id_top_image_page_slider);
        topImagePageSliderCard.setImageList(LifeFractionData.getTopImagePageSliderCardData());
        topImagePageSliderCard.startAutoPlay(PLAY_INTERVAL);
    }

    private void initFeaturesContainer() {
        GridContainer featuresContainer = new GridContainer((TableLayout) lifeFraction.findComponentById(
                ResourceTable.Id_features_container));
        featuresContainer.setGridItemList(LifeFractionData.getFeaturesContainerData(slice));
        featuresContainer.setItemClickedListener((Component component, GridItem gridItem) -> {
            if (gridItem.getIdentification() == 9) {
                MoreAbilitySlice moreAbilitySlice = new MoreAbilitySlice();
                slice.present(moreAbilitySlice, new Intent());
            }
        });
    }

    private void initImagePageSliderCard() {
        ImagePageSliderCard imagePageSliderCard = (ImagePageSliderCard) lifeFraction.findComponentById(
                ResourceTable.Id_image_page_slider);
        imagePageSliderCard.setImageList(LifeFractionData.getImagePageSliderCardData());
        imagePageSliderCard.startAutoPlay(PLAY_INTERVAL);
    }

    private void initRecommendCard() {
        RecommendCard recommendCard = (RecommendCard) lifeFraction.findComponentById(ResourceTable.Id_recommend_card);
        recommendCard.setRecommendTitle(LifeFractionData.getRecommendCardTitle(slice));
        recommendCard.setRecommendItemList(LifeFractionData.getRecommendCardData(slice));
        recommendCard.setRecommendItemClickedListener((component, index) -> {
            WebAbilitySlice webAbilitySlice = new WebAbilitySlice();
            slice.present(webAbilitySlice, new Intent());
        });
    }

    private void initLikeCard() {
        LikeCard likeCard = (LikeCard) lifeFraction.findComponentById(ResourceTable.Id_like_card);
        likeCard.setLikeTitle(LifeFractionData.getLikeCardTitle(slice));
        likeCard.setLikeItemList(LifeFractionData.getLikeCardData(slice));
        likeCard.setLikeListItemClickedListener((listContainer, component, index, len) -> {
            WebAbilitySlice webAbilitySlice = new WebAbilitySlice();
            slice.present(webAbilitySlice, new Intent());
        });
    }

    private void initSearchBar() {
        searchBar = (DirectionalLayout) lifeFraction.findComponentById(ResourceTable.Id_search_bar);
        city = (Text) searchBar.findComponentById(ResourceTable.Id_city);
        pullDownImage = (Image) searchBar.findComponentById(ResourceTable.Id_pull_down_image);
        searchBox = (SearchBox) searchBar.findComponentById(ResourceTable.Id_search_box);
        serviceImage = (Image) searchBar.findComponentById(ResourceTable.Id_service_image);
        searchBox.setEnabled(false);
    }

    private void updateSearchBarAlpha(int scrollHeight) {
        RgbColor whiteColor = RgbColor.fromArgbInt(Color.WHITE.getValue());
        RgbColor blackColor = LifeFractionData.getSearchBarBlackColor(slice);
        Color blackTextColor = LifeFractionData.getSearchBarTextBlackColor(slice);

        ShapeElement shapeElement = new ShapeElement();
        shapeElement.setShape(ShapeElement.RECTANGLE);
        shapeElement.setRgbColor(whiteColor);
        if (scrollHeight > searchBar.getHeight()) {
            shapeElement.setAlpha(ALPHA_MAX);
            city.setTextColor(blackTextColor);
            pullDownImage.setPixelMap(ResourceTable.Media_pull_down_black);
            searchBox.setBackgroundColor(blackColor);
            serviceImage.setPixelMap(ResourceTable.Media_service_black);
        } else {
            shapeElement.setAlpha(scrollHeight * ALPHA_MAX / searchBar.getHeight());
            city.setTextColor(Color.WHITE);
            pullDownImage.setPixelMap(ResourceTable.Media_pull_down_white);
            searchBox.setBackgroundColor(whiteColor);
            serviceImage.setPixelMap(ResourceTable.Media_service_white);
        }
        searchBar.setBackground(shapeElement);
    }
}
