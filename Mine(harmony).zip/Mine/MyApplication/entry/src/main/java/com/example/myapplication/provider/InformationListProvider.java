package com.example.myapplication.provider;

import com.example.myapplication.ResourceTable;
import com.example.myapplication.model.InformationItem;

import ohos.agp.components.BaseItemProvider;
import ohos.agp.components.Component;
import ohos.agp.components.ComponentContainer;
import ohos.agp.components.Image;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.Text;
import ohos.app.Context;

import java.util.List;

/**
 * InformationListContainer item provider
 */
public class InformationListProvider extends BaseItemProvider {
    private final Context context;
    private final List<InformationItem> informationItemList;

    public InformationListProvider(Context context, List<InformationItem> informationItemList) {
        this.context = context;
        this.informationItemList = informationItemList;
    }

    @Override
    public int getCount() {
        return informationItemList == null ? 0 : informationItemList.size();
    }

    @Override
    public Object getItem(int position) {
        if (informationItemList != null && position > 0 && position < informationItemList.size()) {
            return informationItemList.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Component getComponent(int position, Component component, ComponentContainer componentContainer) {
        Component informationListItem;
        InformationListHolder informationListHolder;
        InformationItem item = this.informationItemList.get(position);
        if (component == null) {
            informationListItem = LayoutScatter.getInstance(context).parse(
                    ResourceTable.Layout_information_item, null, false);
            informationListHolder = new InformationListHolder(informationListItem);
            informationListItem.setTag(informationListHolder);
        } else {
            informationListItem = component;
            informationListHolder = (InformationListHolder) informationListItem.getTag();
        }
        informationListHolder.title.setText(item.getTitle());
        informationListHolder.desc.setText(item.getDesc());
        informationListHolder.image.setPixelMap(item.getImageId());
        return informationListItem;
    }

    /**
     * InformationListContainer view holder
     */
    public static class InformationListHolder {
        Text title;
        Text desc;
        Image image;

        InformationListHolder(Component component) {
            title = (Text) component.findComponentById(ResourceTable.Id_title);
            desc = (Text) component.findComponentById(ResourceTable.Id_desc);
            image = (Image) component.findComponentById(ResourceTable.Id_image);
        }
    }
}