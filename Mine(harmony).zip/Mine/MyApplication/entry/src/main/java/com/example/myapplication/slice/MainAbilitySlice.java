package com.example.myapplication.slice;

import com.example.myapplication.ResourceTable;
import com.example.myapplication.data.MainAbilitySliceData;
import com.example.myapplication.fraction.HomeFraction;
import com.example.myapplication.fraction.LifeFraction;

import com.example.myapplication.model.NavigationItem;

import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.ability.fraction.Fraction;
import ohos.aafwk.ability.fraction.FractionAbility;
import ohos.aafwk.ability.fraction.FractionScheduler;
import ohos.aafwk.content.Intent;
import ohos.agp.components.Component;
import ohos.agp.components.DependentLayout;
import ohos.agp.components.DirectionalLayout;
import ohos.agp.components.Image;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.Text;
import ohos.agp.utils.Color;
import ohos.global.resource.NotExistException;
import ohos.global.resource.WrongTypeException;
import ohos.hiviewdfx.HiLog;
import ohos.hiviewdfx.HiLogLabel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Main ability slice contains two fractions:  {@link HomeFraction} {@link LifeFraction}.
 * Those fractions are used to display the home page and life page.
 * You can switch the page displayed by clicking on the navigation menu at the bottom.
 * All the data is in {@link MainAbilitySliceData}.
 */
public class MainAbilitySlice extends AbilitySlice {
    private static final HiLogLabel LABEL_LOG = new HiLogLabel(HiLog.DEBUG, 0, "MainAbilitySlice");
    private static final int INIT_FRACTION_INDEX = 0;
    private final Fraction[] fractions = new Fraction[]{new HomeFraction(this), new LifeFraction(this)};

    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        DependentLayout dependentLayout = (DependentLayout) LayoutScatter.getInstance(this)
                .parse(ResourceTable.Layout_ability_main, null, false);
        setUIContent(dependentLayout);

        initFractions();
        setFraction(INIT_FRACTION_INDEX);
        initNavigationMenu();
    }

    @Override
    protected void onActive() {
        initBackgroundColor();
    }

    /**
     * When the ability slice ends or is destroyed, the fractions in the fractionManager are removed.
     */
    @Override
    public void onStop() {
        super.onStop();
        FractionScheduler fractionScheduler = ((FractionAbility) getAbility()).getFractionManager()
                .startFractionScheduler();
        for (Fraction fraction : fractions) {
            fractionScheduler.remove(fraction);
        }
        fractionScheduler.submit();
    }

    private void initBackgroundColor() {
        try {
            getWindow().setStatusBarColor(Color.getIntColor(getContext()
                    .getResourceManager().getElement(ResourceTable.Color_status_bar_background).getString()));
            getWindow().setNavigationBarColor(Color.getIntColor(getContext()
                    .getResourceManager().getElement(ResourceTable.Color_navigation_background).getString()));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get background color fail");
        }
    }

    /**
     * Add homeFraction and lifeFraction to fractionManager.
     */
    private void initFractions() {
        FractionScheduler fractionScheduler = ((FractionAbility) getAbility()).getFractionManager()
                .startFractionScheduler();
        for (Fraction fraction : fractions) {
            fractionScheduler.add(ResourceTable.Id_fraction_container, fraction);
        }
        fractionScheduler.submit();
    }

    /**
     * Set the fraction that currently needs to be displayed.
     *
     * @param fractionIndex fraction index
     */
    private void setFraction(int fractionIndex) {
        FractionScheduler fractionScheduler = ((FractionAbility) getAbility()).getFractionManager()
                .startFractionScheduler();
        for (Fraction fraction : fractions) {
            fractionScheduler.hide(fraction);
        }
        fractionScheduler.show(fractions[fractionIndex]);
        fractionScheduler.submit();
    }

    /**
     * Initialize the bottom navigation menu, dynamically add navigation items to the navigation menu
     * based on the number of fractions and highlight the current item.
     */
    private void initNavigationMenu() {
        DirectionalLayout navigationMenu = (DirectionalLayout) findComponentById(ResourceTable.Id_navigation_menu);

        List<NavigationItem> navigationItemList = MainAbilitySliceData.getNavigationItemList(this);
        Color normalTextColor = MainAbilitySliceData.getNormalTextColor(this);
        Color selectedTextColor = MainAbilitySliceData.getSelectedTextColor(this);

        List<Image> navigationItemImageList = new ArrayList<>();
        List<Text> navigationItemTextList = new ArrayList<>();
        for (int i = 0; i < fractions.length; i++) {
            DirectionalLayout navigationItem = (DirectionalLayout) LayoutScatter.getInstance(getContext())
                    .parse(ResourceTable.Layout_navigation_item, navigationMenu, false);
            Image navigationItemImage = (Image)
                    navigationItem.findComponentById(ResourceTable.Id_navigation_item_image);
            Text navigationItemText = (Text) navigationItem.findComponentById(ResourceTable.Id_navigation_item_text);

            navigationItemImage.setPixelMap(i == MainAbilitySlice.INIT_FRACTION_INDEX ?
                    navigationItemList.get(i).getSelectedImageId() : navigationItemList.get(i).getNormalImageId());
            navigationItemText.setTextColor(i == MainAbilitySlice.INIT_FRACTION_INDEX ?
                    selectedTextColor : normalTextColor);
            navigationItemText.setText(navigationItemList.get(i).getText());

            navigationItemImageList.add(navigationItemImage);
            navigationItemTextList.add(navigationItemText);

            final int currentNavigationIndex = i;
            navigationItem.setClickedListener((Component component) -> {
                for (int j = 0; j < navigationItemImageList.size(); j++) {
                    navigationItemImageList.get(j).setPixelMap(navigationItemList.get(j).getNormalImageId());
                    navigationItemTextList.get(j).setTextColor(normalTextColor);
                }
                navigationItemImage.setPixelMap(navigationItemList.get(currentNavigationIndex).getSelectedImageId());
                navigationItemText.setTextColor(selectedTextColor);
                setFraction(currentNavigationIndex);
            });
            navigationMenu.addComponent(navigationItem);
        }
    }
}
