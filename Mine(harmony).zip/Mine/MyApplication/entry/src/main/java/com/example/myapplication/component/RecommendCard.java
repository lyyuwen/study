package com.example.myapplication.component;

import com.example.myapplication.ResourceTable;
import com.example.myapplication.model.RecommendItem;

import ohos.agp.components.AttrSet;
import ohos.agp.components.Component;
import ohos.agp.components.DirectionalLayout;
import ohos.agp.components.Image;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.Text;
import ohos.app.Context;

import java.util.List;

/**
 * RecommendCard
 */
public class RecommendCard extends DirectionalLayout {
    private Text recommendTitle;
    private DirectionalLayout recommendItemContainer;

    private ClickedListener recommendMoreClickedListener;
    private RecommendItemClickedListener recommendItemClickedListener;

    public RecommendCard(Context context) {
        super(context);
        initRecommendCard();
    }

    public RecommendCard(Context context, AttrSet attrSet) {
        super(context, attrSet);
        initRecommendCard();
    }

    public RecommendCard(Context context, AttrSet attrSet, String styleName) {
        super(context, attrSet, styleName);
        initRecommendCard();
    }

    private void initRecommendCard() {
        Component recommendCard = LayoutScatter.getInstance(
                getContext()).parse(ResourceTable.Layout_recommend_card, null, false);
        this.addComponent(recommendCard);

        recommendTitle = (Text) recommendCard.findComponentById(ResourceTable.Id_recommend_title);
        DirectionalLayout recommendMore = (DirectionalLayout) recommendCard.findComponentById(
                ResourceTable.Id_recommend_more);
        recommendItemContainer = (DirectionalLayout) recommendCard.findComponentById(
                ResourceTable.Id_recommend_item_container);

        recommendMore.setClickedListener(component -> {
            if (recommendMoreClickedListener != null) {
                recommendMoreClickedListener.onClick(component);
            }
        });
    }

    /**
     * set recommend card title
     *
     * @param recommendTitleText recommend card title
     */
    public void setRecommendTitle(String recommendTitleText) {
        this.recommendTitle.setText(recommendTitleText);
    }

    /**
     * set recommend item list
     *
     * @param recommendItemList recommend item list
     */
    public void setRecommendItemList(List<RecommendItem> recommendItemList) {
        for (int i = 0; i < recommendItemList.size(); i++) {
            Component recommendItem = setRecommendItem(recommendItemList.get(i));
            int recommendIndex = i;
            recommendItem.setClickedListener(component -> {
                if (recommendItemClickedListener != null) {
                    recommendItemClickedListener.onRecommendItemClicked(component, recommendIndex);
                }
            });
        }
    }

    private Component setRecommendItem(RecommendItem recommendItem) {
        Component component = LayoutScatter.getInstance(
                getContext()).parse(ResourceTable.Layout_recommend_item, null, false);
        Image image = (Image) component.findComponentById(ResourceTable.Id_image);
        Text name = (Text) component.findComponentById(ResourceTable.Id_name);
        Text desc = (Text) component.findComponentById(ResourceTable.Id_desc);

        image.setPixelMap(recommendItem.getImageId());
        name.setText(recommendItem.getName());
        desc.setText(recommendItem.getDesc());
        DirectionalLayout.LayoutConfig layoutConfig = new LayoutConfig();
        layoutConfig.weight = 1;

        component.setLayoutConfig(layoutConfig);

        recommendItemContainer.addComponent(component);
        return component;
    }

    public void setRecommendMoreClickedListener(ClickedListener recommendMoreClickedListener) {
        this.recommendMoreClickedListener = recommendMoreClickedListener;
    }

    /**
     * set recommend item clicked listener
     *
     * @param recommendItemClickedListener recommend item clicked listener
     */
    public void setRecommendItemClickedListener(RecommendItemClickedListener recommendItemClickedListener) {
        this.recommendItemClickedListener = recommendItemClickedListener;
    }

    /**
     * recommend item clicked listener
     */
    public interface RecommendItemClickedListener {
        void onRecommendItemClicked(Component component, int index);
    }
}
