package com.example.myapplication;

import ohos.aafwk.ability.Ability;
import ohos.global.resource.RawFileDescriptor;
import ohos.utils.net.Uri;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * The WebView does not support loading resource files or local files through the File protocol.
 * When an application needs to load resource files or local files, access the files through the DataAbility.
 */
public class DataAbility extends Ability {
    private static final String ENTRY_PATH_PREFIX = "entry/resources";

    @Override
    public RawFileDescriptor openRawFile(Uri uri, String mode) throws FileNotFoundException {
        final int splitChar = '/';
        if (uri == null) {
            throw new FileNotFoundException("Invalid Uri");
        }
        String path = uri.getEncodedPath();
        final int splitIndex = path.indexOf(splitChar, 1);
        if (splitIndex < 0) {
            throw new FileNotFoundException("Invalid Uri " + uri);
        }

        String targetPath = path.substring(splitIndex);
        try {
            return getResourceManager().getRawFileEntry(ENTRY_PATH_PREFIX + targetPath).openRawFileDescriptor();
        } catch (IOException e) {
            throw new FileNotFoundException("Not found support raw file at " + uri);
        }
    }
}
