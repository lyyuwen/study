package com.example.myapplication.provider;

import com.example.myapplication.ResourceTable;
import com.example.myapplication.model.LikeItem;

import ohos.agp.components.BaseItemProvider;
import ohos.agp.components.Component;
import ohos.agp.components.ComponentContainer;
import ohos.agp.components.Image;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.Text;
import ohos.app.Context;

import java.util.List;

/**
 * LikeListContainer item provider
 */
public class LikeListProvider extends BaseItemProvider {
    private final Context context;
    private final List<LikeItem> likeItemList;

    public LikeListProvider(Context context, List<LikeItem> likeItemList) {
        this.context = context;
        this.likeItemList = likeItemList;
    }

    @Override
    public int getCount() {
        return likeItemList == null ? 0 : likeItemList.size();
    }

    @Override
    public Object getItem(int position) {
        if (likeItemList != null && position > 0 && position < likeItemList.size()) {
            return likeItemList.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Component getComponent(int position, Component component, ComponentContainer componentContainer) {
        Component likeListItem;
        LikeListHolder likeListHolder;
        LikeItem item = this.likeItemList.get(position);
        if (component == null) {
            likeListItem = LayoutScatter.getInstance(context).parse(
                    ResourceTable.Layout_like_item, null, false);
            likeListHolder = new LikeListHolder(likeListItem);
            likeListItem.setTag(likeListHolder);
        } else {
            likeListItem = component;
            likeListHolder = (LikeListHolder) likeListItem.getTag();
        }
        likeListHolder.title.setText(item.getTitle());
        likeListHolder.desc.setText(item.getDesc());
        likeListHolder.price.setText(item.getPrice());
        likeListHolder.sold.setText(item.getSold());
        likeListHolder.image.setPixelMap(item.getImageId());
        return likeListItem;
    }

    /**
     * LikeListContainer view holder
     */
    public static class LikeListHolder {
        Text title;
        Text desc;
        Text price;
        Text sold;
        Image image;

        LikeListHolder(Component component) {
            title = (Text) component.findComponentById(ResourceTable.Id_title);
            desc = (Text) component.findComponentById(ResourceTable.Id_desc);
            price = (Text) component.findComponentById(ResourceTable.Id_price);
            sold = (Text) component.findComponentById(ResourceTable.Id_sold);
            image = (Image) component.findComponentById(ResourceTable.Id_image);
        }
    }
}
