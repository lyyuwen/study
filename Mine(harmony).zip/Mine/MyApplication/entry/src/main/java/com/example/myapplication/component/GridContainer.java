package com.example.myapplication.component;

import com.example.myapplication.ResourceTable;
import com.example.myapplication.model.GridItem;

import ohos.agp.colors.RgbColor;
import ohos.agp.components.Component;
import ohos.agp.components.ComponentTransition;
import ohos.agp.components.DirectionalLayout;
import ohos.agp.components.TableLayout;
import ohos.agp.components.Image;
import ohos.agp.components.Text;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.AttrHelper;
import ohos.agp.components.element.ShapeElement;
import ohos.agp.utils.Color;
import ohos.agp.utils.MimeData;
import ohos.agp.utils.Point;
import ohos.agp.utils.Rect;
import ohos.agp.window.service.Display;
import ohos.agp.window.service.DisplayManager;
import ohos.app.Context;
import ohos.multimodalinput.event.MmiPoint;
import ohos.multimodalinput.event.TouchEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static ohos.agp.components.Component.INVISIBLE;
import static ohos.agp.components.Component.VISIBLE;

/**
 * Custom grid component, there are three operation types: none operate type, add operate type, and remove operate type.
 * The add operate type and remove operate type can be used to add and remove items from the container.
 * The added and removed items can be passed through the listener when the operate type is add operate type and remove
 * operate type.
 */
public class GridContainer {
    /**
     * none operate type
     */
    public static final int NONE_TYPE = 0;
    /**
     * add operate type
     */
    public static final int ADD_TYPE = 1;
    /**
     * remove operate type
     */
    public static final int REMOVE_TYPE = 2;

    private static final float DRAG_SCALE = 1.22f;
    private static final int CORNER_RADIUS = 20;

    private static final int BACKGROUND_WIDTH = 64;
    private static final int BACKGROUND_HEIGHT = 64;
    private static final int NORMAL_ALPHA = 13;
    private static final int DRAG_ALPHA = 26;
    private static final int MAX_GRID_ITEM_COUNT = 8;
    private final List<GridHolder> gridHolderList = new ArrayList<>();
    private final TableLayout tableLayout;
    private int operateType = NONE_TYPE;
    private int horizontalMargin = 0;
    private int itemMarginBottom = 0;
    private boolean isItemDrag = false;
    private List<GridItem> gridItemList;
    private Component selectedComponent;
    private boolean isComponentOnDrag;
    private ComponentTransition componentTransition;

    private ItemClickedListener itemClickedListener;
    private ItemLongClickedListener itemLongClickedListener;
    private AddClickedListener addClickedListener;
    private RemoveClickedListener removeClickedListener;

    /**
     * initialization function
     *
     * @param tableLayout layout used by gridContainer
     */
    public GridContainer(TableLayout tableLayout) {
        this.tableLayout = tableLayout;
        setItemLongClickedListener();
        setTouchEventListener();
        initComponentTransition();
    }

    private void initComponentTransition() {
        componentTransition = new ComponentTransition();
        componentTransition.removeTransitionType(ComponentTransition.SELF_GONE);
        componentTransition.removeTransitionType(ComponentTransition.OTHERS_GONE);
        componentTransition.removeTransitionType(ComponentTransition.CHANGING);
        componentTransition.removeTransitionType(ComponentTransition.SELF_SHOW);
    }

    /**
     * get the item list for gridContainer
     *
     * @return gridContainer item list
     */
    public List<GridItem> getGridItemList() {
        return gridItemList;
    }

    /**
     * set the item list for gridContainer
     *
     * @param gridItemList gridContainer item list
     */
    public void setGridItemList(List<GridItem> gridItemList) {
        this.gridItemList = gridItemList;
        for (int i = 0; i < gridItemList.size(); i++) {
            Component component = getComponent(gridItemList.get(i));
            this.addToContainer(component, i);
        }
    }

    /**
     * add the item to gridContainer
     *
     * @param gridItem gridContainer item
     * @return true if the item already added, otherwise false
     */
    public boolean addToContainer(GridItem gridItem) {
        if (tableLayout.getChildCount() == MAX_GRID_ITEM_COUNT) {
            return false;
        }
        gridItemList.add(gridItem);
        Component component = getComponent(gridItem);
        addToContainer(component, gridItemList.size() - 1);
        return true;
    }

    /**
     * set feature name color
     *
     * @param featureNameColor feature name color
     */
    public void setFeatureNameColor(Color featureNameColor) {
        for (GridHolder gridHolder : gridHolderList) {
            gridHolder.featureName.setTextColor(featureNameColor);
        }
    }

    /**
     * set gridContainer item margin bottom
     *
     * @param itemMarginBottom item margin bottom
     */
    public void setItemMarginBottom(int itemMarginBottom) {
        this.itemMarginBottom = itemMarginBottom;
    }

    /**
     * set gridContainer horizontal margin
     *
     * @param horizontalMargin gridContainer horizontal margin
     */
    public void setHorizontalMargin(int horizontalMargin) {
        this.horizontalMargin = horizontalMargin;
    }

    /**
     * determine whether the gridContainer contains the item
     *
     * @param gridItem gridContainer item
     * @return if the gridContainer contains the item return index, otherwise return -1
     */
    public int containGridItem(GridItem gridItem) {
        for (int i = 0; i < gridItemList.size(); i++) {
            if (gridItem.getIdentification() == gridItemList.get(i).getIdentification()) {
                return i;
            }
        }
        return -1;
    }

    /**
     * set the operate type according to the grid item index
     *
     * @param operateType   operate type
     * @param gridItemIndex grid item index
     */
    public void setOperateType(int operateType, int gridItemIndex) {
        if (operateType == ADD_TYPE) {
            gridHolderList.get(gridItemIndex).operateImage.setVisibility(VISIBLE);
            gridHolderList.get(gridItemIndex).operateImage.setPixelMap(ResourceTable.Media_add_item);
        } else if (operateType == REMOVE_TYPE) {
            gridHolderList.get(gridItemIndex).operateImage.setVisibility(VISIBLE);
            gridHolderList.get(gridItemIndex).operateImage.setPixelMap(ResourceTable.Media_remove_item);

        } else {
            gridHolderList.get(gridItemIndex).operateImage.setVisibility(INVISIBLE);
        }
    }

    /**
     * set all grid items operate type
     *
     * @param operateType operate type
     */
    public void setOperateType(int operateType) {
        this.operateType = operateType;
        ShapeElement shapeElement = new ShapeElement();
        shapeElement.setBounds(0, 0, AttrHelper.vp2px(BACKGROUND_WIDTH, tableLayout.getContext()),
                AttrHelper.vp2px(BACKGROUND_HEIGHT, tableLayout.getContext()));
        shapeElement.setCornerRadius(CORNER_RADIUS);
        if (operateType == ADD_TYPE) {
            for (GridHolder gridHolder : gridHolderList) {
                gridHolder.operateImage.setVisibility(VISIBLE);
                gridHolder.operateImage.setPixelMap(ResourceTable.Media_add_item);
                shapeElement.setRgbColor(RgbColor.fromArgbInt(Color.BLACK.getValue()));
                shapeElement.setAlpha(NORMAL_ALPHA);
                gridHolder.backgroundLayout.setBackground(shapeElement);
            }
        } else if (operateType == REMOVE_TYPE) {
            for (GridHolder gridHolder : gridHolderList) {
                gridHolder.operateImage.setVisibility(VISIBLE);
                gridHolder.operateImage.setPixelMap(ResourceTable.Media_remove_item);
                shapeElement.setRgbColor(RgbColor.fromArgbInt(Color.BLACK.getValue()));
                shapeElement.setAlpha(NORMAL_ALPHA);
                gridHolder.backgroundLayout.setBackground(shapeElement);
            }
        } else {
            for (GridHolder gridHolder : gridHolderList) {
                gridHolder.operateImage.setVisibility(INVISIBLE);
                shapeElement.setRgbColor(RgbColor.fromRgbaInt(Color.WHITE.getValue()));
                gridHolder.backgroundLayout.setBackground(shapeElement);
            }
        }
    }

    /**
     * set whether each item can be dragged
     *
     * @param isItemDrag whether each item can be dragged
     */
    public void setItemDrag(boolean isItemDrag) {
        this.isItemDrag = isItemDrag;
    }

    /**
     * create the component from the item and return the component
     *
     * @param gridItem gridContainer item
     * @return the created component
     */
    private Component getComponent(GridItem gridItem) {
        Component component = LayoutScatter.getInstance(
                tableLayout.getContext()).parse(ResourceTable.Layout_grid_item, tableLayout, false);
        GridHolder gridHolder = new GridHolder(component);
        gridHolder.featureIcon.setPixelMap(gridItem.getFeatureIcon());
        gridHolder.featureName.setText(gridItem.getFeatureText());
        gridHolderList.add(gridHolder);
        component.setMarginBottom(AttrHelper.vp2px(itemMarginBottom, tableLayout.getContext()));
        return component;
    }

    /**
     * create the drag component from the item and return the drag component
     *
     * @param gridItem gridContainer item
     * @return the created drag component
     */
    private Component getDragComponent(GridItem gridItem) {
        Component component = LayoutScatter.getInstance(
                tableLayout.getContext()).parse(ResourceTable.Layout_grid_item, null, false);
        GridHolder gridHolder = new GridHolder(component);
        gridHolder.featureIcon.setPixelMap(gridItem.getFeatureIcon());
        gridHolder.featureName.setText(gridItem.getFeatureText());
        ShapeElement shapeElement = new ShapeElement();
        shapeElement.setRgbColor(RgbColor.fromArgbInt(Color.BLACK.getValue()));
        shapeElement.setAlpha(DRAG_ALPHA);
        shapeElement.setCornerRadius(CORNER_RADIUS);
        gridHolder.backgroundLayout.setBackground(shapeElement);
        gridHolder.operateImage.setVisibility(VISIBLE);
        gridHolder.operateImage.setPixelMap(ResourceTable.Media_remove_item);
        component.setMarginBottom(AttrHelper.vp2px(itemMarginBottom, tableLayout.getContext()));
        return component;
    }

    /**
     * add the component created based on the grid item to the tableLayout
     *
     * @param component      the component created based on the item
     * @param componentIndex component index
     */
    private void addToContainer(Component component, int componentIndex) {
        GridItem gridItem = gridItemList.get(componentIndex);
        GridHolder gridHolder = gridHolderList.get(componentIndex);
        component.setWidth(
                (getScreenWidth(tableLayout.getContext()) - 2 * horizontalMargin) / tableLayout.getColumnCount());
        component.setClickedListener((Component clickedComponent) -> {
            if (itemClickedListener != null) {
                itemClickedListener.onItemClicked(clickedComponent, gridItem);
            }
        });
        component.setLongClickedListener((Component clickedComponent) -> {
            if (isItemDrag) {
                itemLongClickedListener.onLongItemClicked(clickedComponent, gridItem);
            }
        });
        gridHolderList.get(componentIndex).operateImage.setClickedListener((Component clickedComponent) -> {
            removeComponentTransition();
            if (operateType == REMOVE_TYPE) {
                tableLayout.removeComponent(component);
                gridItemList.remove(gridItem);
                gridHolderList.remove(gridHolder);
                if (removeClickedListener != null) {
                    removeClickedListener.getRemoveItem(gridItem);
                }
            }
            if (operateType == ADD_TYPE) {
                if (addClickedListener != null) {
                    if (addClickedListener.getAddItem(gridItem)) {
                        gridHolder.operateImage.setVisibility(INVISIBLE);
                    }
                }
            }
        });
        tableLayout.addComponent(component);
    }

    /**
     * get screen width
     *
     * @param context context
     * @return screen width
     */
    private int getScreenWidth(Context context) {
        int screenWidth = 0;
        DisplayManager displayManager = DisplayManager.getInstance();
        Optional<Display> optDisplay = displayManager.getDefaultDisplay(context);
        if (optDisplay.isPresent()) {
            Point point = new Point(0, 0);
            optDisplay.get().getSize(point);
            screenWidth = (int) point.position[0];
        }
        return screenWidth;
    }

    /**
     * set grid container item long clicked listener
     */
    private void setItemLongClickedListener() {
        setItemLongClickedListener((Component component, GridItem gridItem) -> {
            Component dragComponent = getDragComponent(gridItem);
            dragComponent.setScale(DRAG_SCALE, DRAG_SCALE);
            dragComponent.setWidth(component.getWidth());
            dragComponent.setHeight(component.getHeight());
            Component.DragFeedbackProvider dragFeedbackProvider = new Component.DragFeedbackProvider(dragComponent);
            component.startDragAndDrop(new MimeData(), dragFeedbackProvider);
            component.setVisibility(INVISIBLE);
            selectedComponent = component;
            isComponentOnDrag = true;
            bindComponentTransition();
        });
    }

    /**
     * bind component transition from tableLayout
     */
    private void bindComponentTransition() {
        componentTransition.addTransitionType(ComponentTransition.OTHERS_SHOW);
        tableLayout.setComponentTransition(componentTransition);
    }

    /**
     * remove table layout component transition
     */
    private void removeComponentTransition() {
        componentTransition.removeTransitionType(ComponentTransition.OTHERS_SHOW);
        tableLayout.setComponentTransition(componentTransition);
    }

    /**
     * set tableLayout touch event listener
     */
    private void setTouchEventListener() {
        tableLayout.setTouchEventListener((Component component, TouchEvent touchEvent) -> {
            MmiPoint touchPoint = touchEvent.getPointerPosition(touchEvent.getIndex());
            switch (touchEvent.getAction()) {
                case TouchEvent.PRIMARY_POINT_DOWN:
                    return true;
                case TouchEvent.PRIMARY_POINT_UP:
                case TouchEvent.CANCEL:
                    if (isComponentOnDrag) {
                        selectedComponent.setVisibility(VISIBLE);
                        isComponentOnDrag = false;
                        removeComponentTransition();
                        return true;
                    }
                    break;
                case TouchEvent.POINT_MOVE:
                    if (!isComponentOnDrag) {
                        break;
                    }
                    int lastPosition = pointToPosition(touchPoint);
                    swapComponent(lastPosition);
                    return true;
            }
            return false;
        });
    }

    /**
     * get component position according to the touch point
     *
     * @param touchPoint touch point
     * @return component position
     */
    private int pointToPosition(MmiPoint touchPoint) {
        int pointX = (int) touchPoint.getX();
        int pointY = (int) touchPoint.getY();
        int childCount = tableLayout.getChildCount();
        for (int i = 0; i < childCount; i++) {
            Rect child = tableLayout.getComponentAt(i).getComponentPosition();
            if (child.isInclude(pointX, pointY)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * swap component by position
     *
     * @param lastPosition last position
     */
    private void swapComponent(int lastPosition) {
        int currentPosition = tableLayout.getChildIndex(selectedComponent);
        if (lastPosition == -1 || lastPosition == currentPosition) {
            return;
        }
        tableLayout.removeComponent(selectedComponent);
        tableLayout.addComponent(selectedComponent, lastPosition);
        selectedComponent = tableLayout.getComponentAt(lastPosition);
    }

    /**
     * set item clicked listener
     *
     * @param itemClickedListener item clicked listener
     */
    public void setItemClickedListener(ItemClickedListener itemClickedListener) {
        this.itemClickedListener = itemClickedListener;
    }

    /**
     * set item long clicked listener
     *
     * @param itemLongClickedListener item long clicked listener
     */
    private void setItemLongClickedListener(ItemLongClickedListener itemLongClickedListener) {
        this.itemLongClickedListener = itemLongClickedListener;
    }

    /**
     * set add clicked listener
     *
     * @param addClickedListener add clicked listener
     */
    public void setAddClickedListener(AddClickedListener addClickedListener) {
        this.addClickedListener = addClickedListener;
    }

    /**
     * set remove clicked listener
     *
     * @param removeClickedListener set remove clicked listener
     */
    public void setRemoveClickedListener(RemoveClickedListener removeClickedListener) {
        this.removeClickedListener = removeClickedListener;
    }

    /**
     * gridContainer item clicked listener
     */
    public interface ItemClickedListener {
        void onItemClicked(Component component, GridItem gridItem);
    }

    /**
     * gridContainer item long clicked listener
     */
    private interface ItemLongClickedListener {
        void onLongItemClicked(Component component, GridItem gridItem);
    }

    /**
     * gridContainer add image clicked listener
     */
    public interface AddClickedListener {
        boolean getAddItem(GridItem gridItem);
    }

    /**
     * gridContainer remove image clicked listener
     */
    public interface RemoveClickedListener {
        void getRemoveItem(GridItem gridItem);
    }

    /**
     * gridContainer view holder
     */
    public static class GridHolder {
        DirectionalLayout backgroundLayout;
        Image featureIcon;
        Text featureName;
        Image operateImage;

        GridHolder(Component component) {
            backgroundLayout = (DirectionalLayout) component.findComponentById(ResourceTable.Id_background_layout);
            featureIcon = (Image) component.findComponentById(ResourceTable.Id_feature_icon);
            featureName = (Text) component.findComponentById(ResourceTable.Id_feature_name);
            operateImage = (Image) component.findComponentById(ResourceTable.Id_operate_image);
        }
    }
}
