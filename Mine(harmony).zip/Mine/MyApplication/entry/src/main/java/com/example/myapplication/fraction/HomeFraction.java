package com.example.myapplication.fraction;

import com.example.myapplication.ResourceTable;
import com.example.myapplication.component.GridContainer;
import com.example.myapplication.component.ImagePageSliderCard;
import com.example.myapplication.component.InformationCard;
import com.example.myapplication.component.RecommendCard;
import com.example.myapplication.component.SearchBox;
import com.example.myapplication.component.TextPageSliderCard;
import com.example.myapplication.data.HomeFractionData;
import com.example.myapplication.model.GridItem;
import com.example.myapplication.slice.MoreAbilitySlice;

import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.ability.fraction.Fraction;
import ohos.aafwk.content.Intent;
import ohos.agp.colors.RgbColor;
import ohos.agp.components.AttrHelper;
import ohos.agp.components.Component;
import ohos.agp.components.ComponentContainer;
import ohos.agp.components.DirectionalLayout;
import ohos.agp.components.Image;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.ScrollView;
import ohos.agp.components.TableLayout;
import ohos.agp.components.element.ShapeElement;
import ohos.agp.utils.Color;

/**
 * Home fraction display home page. All the data is in {@link HomeFractionData}.
 */
public class HomeFraction extends Fraction {
    private static final int PLAY_INTERVAL = 3000;
    private static final int HORIZONTAL_MARGIN = 16;
    private static final int ALPHA_MAX = 254;

    private final AbilitySlice slice;

    private Component homeFraction;

    private DirectionalLayout searchBar;
    private Image loginImage;
    private SearchBox searchBox;
    private Image serviceImage;

    public HomeFraction(AbilitySlice slice) {
        this.slice = slice;
    }

    @Override
    protected Component onComponentAttached(LayoutScatter scatter, ComponentContainer container, Intent intent) {
        homeFraction = scatter.parse(ResourceTable.Layout_fraction_home, container, false);

        initScrollView();
        initCoreFeaturesContainer();
        initFeaturesContainer();
        initTextPageSliderCard();
        initImagePageSliderCard();
        initRecommendCard();
        initInformationCard();
        initSearchBar();

        return homeFraction;
    }

    private void initScrollView() {
        ScrollView scrollView = (ScrollView) homeFraction.findComponentById(ResourceTable.Id_scroll_view);
        DirectionalLayout globalDirectionalLayout = (DirectionalLayout)
                homeFraction.findComponentById(ResourceTable.Id_global_directional_layout);
        scrollView.setScrolledListener((Component component,
                                        int scrollX, int scrollY, int oldScrollX, int oldScrollY) ->
                updateSearchBarAlpha(-globalDirectionalLayout.getTop()));
    }

    private void initCoreFeaturesContainer() {
        GridContainer coreFeaturesContainer = new GridContainer((TableLayout) homeFraction.findComponentById(
                ResourceTable.Id_core_features_container));
        coreFeaturesContainer.setGridItemList(HomeFractionData.getCoreFeaturesContainerData(slice));
        coreFeaturesContainer.setFeatureNameColor(Color.WHITE);
    }

    private void initFeaturesContainer() {
        GridContainer featuresContainer = new GridContainer((TableLayout) homeFraction.findComponentById(
                ResourceTable.Id_features_container));
        featuresContainer.setHorizontalMargin(AttrHelper.vp2px(HORIZONTAL_MARGIN, getContext()));
        featuresContainer.setGridItemList(HomeFractionData.getFeaturesContainerData(slice));
        featuresContainer.setItemClickedListener((Component component, GridItem gridItem) -> {
            if (gridItem.getIdentification() == 7) {
                MoreAbilitySlice moreAbilitySlice = new MoreAbilitySlice();
                slice.present(moreAbilitySlice, new Intent());
            }
        });
    }

    private void initTextPageSliderCard() {
        TextPageSliderCard textPageSliderCard = (TextPageSliderCard) homeFraction.findComponentById(
                ResourceTable.Id_text_page_slider_card);
        textPageSliderCard.setTextList(HomeFractionData.getTextPageSliderCardData(slice));
        textPageSliderCard.startAutoPlay(PLAY_INTERVAL);
    }

    private void initImagePageSliderCard() {
        ImagePageSliderCard imagePageSliderCard = (ImagePageSliderCard) homeFraction.findComponentById(
                ResourceTable.Id_image_page_slider_card);
        imagePageSliderCard.setImageList(HomeFractionData.getImagePageSliderCardData());
        imagePageSliderCard.startAutoPlay(PLAY_INTERVAL);
    }

    private void initRecommendCard() {
        RecommendCard recommendCard = (RecommendCard) homeFraction.findComponentById(ResourceTable.Id_recommend_card);
        recommendCard.setRecommendTitle(HomeFractionData.getRecommendCardTitle(slice));
        recommendCard.setRecommendItemList(HomeFractionData.getRecommendCardData(slice));
    }

    private void initInformationCard() {
        InformationCard informationCard = (InformationCard) homeFraction.findComponentById(
                ResourceTable.Id_information_card);
        informationCard.setInformationTitle(HomeFractionData.getInformationCardTitle(slice));
        informationCard.setInformationItemList(HomeFractionData.getInformationCardData(slice));
    }

    private void initSearchBar() {
        searchBar = (DirectionalLayout) homeFraction.findComponentById(ResourceTable.Id_search_bar);
        loginImage = (Image) searchBar.findComponentById(ResourceTable.Id_login_image);
        searchBox = (SearchBox) searchBar.findComponentById(ResourceTable.Id_search_box);
        serviceImage = (Image) searchBar.findComponentById(ResourceTable.Id_service_image);
        searchBox.setEnabled(false);
    }

    private void updateSearchBarAlpha(int scrollHeight) {
        RgbColor whiteColor = RgbColor.fromArgbInt(Color.WHITE.getValue());
        RgbColor blackColor = HomeFractionData.getSearchBarBlackColor(slice);

        ShapeElement shapeElement = new ShapeElement();
        shapeElement.setShape(ShapeElement.RECTANGLE);
        shapeElement.setRgbColor(whiteColor);
        if (scrollHeight > searchBar.getHeight()) {
            shapeElement.setAlpha(ALPHA_MAX);
            searchBox.setBackgroundColor(blackColor);
            loginImage.setPixelMap(ResourceTable.Media_login_black);
            serviceImage.setPixelMap(ResourceTable.Media_service_black);
        } else {
            shapeElement.setAlpha(scrollHeight * ALPHA_MAX / searchBar.getHeight());
            searchBox.setBackgroundColor(whiteColor);
            loginImage.setPixelMap(ResourceTable.Media_login_white);
            serviceImage.setPixelMap(ResourceTable.Media_service_white);
        }
        searchBar.setBackground(shapeElement);
    }
}
