package com.example.myapplication.component;

import com.example.myapplication.ResourceTable;
import com.example.myapplication.provider.TextPageSliderProvider;

import ohos.agp.components.AttrSet;
import ohos.agp.components.Component;
import ohos.agp.components.DirectionalLayout;
import ohos.agp.components.Image;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.PageSlider;
import ohos.app.Context;

import java.util.List;

/**
 * TextPageSliderCard can be played automatically.
 */
public class TextPageSliderCard extends DirectionalLayout {
    private PageSlider textPageSlider;

    private int interval = 0;
    private int currentPage = 0;
    private int pageCount = 0;
    private boolean pageSliderShow = true;

    private ClickedListener textMoreClickedListener;
    private TextItemClickedListener textItemClickedListener;

    public TextPageSliderCard(Context context) {
        super(context);
        initPageSlider();
    }

    public TextPageSliderCard(Context context, AttrSet attrSet) {
        super(context, attrSet);
        initPageSlider();
    }

    public TextPageSliderCard(Context context, AttrSet attrSet, String styleName) {
        super(context, attrSet, styleName);
        initPageSlider();
    }

    private void initPageSlider() {
        Component textPageSliderCard = LayoutScatter.getInstance(
                getContext()).parse(ResourceTable.Layout_text_page_slider_card, null, false);
        this.addComponent(textPageSliderCard);

        textPageSlider = (PageSlider) textPageSliderCard.findComponentById(ResourceTable.Id_text_page_slider);
        Image moreText = (Image) textPageSliderCard.findComponentById(ResourceTable.Id_more_text);

        textPageSlider.setSlidingPossible(false);
        textPageSlider.setCircularModeEnabled(true);
        textPageSlider.setOrientation(VERTICAL);

        moreText.setClickedListener(component -> {
            if (textMoreClickedListener != null) {
                textMoreClickedListener.onClick(component);
            }
        });

        setBindStateChangedListener(new BindStateChangedListener() {
            @Override
            public void onComponentBoundToWindow(Component component) {
                if (!pageSliderShow) {
                    startAutoPlay(interval);
                }
                pageSliderShow = true;
            }

            @Override
            public void onComponentUnboundFromWindow(Component component) {
                pageSliderShow = false;
            }
        });
    }

    /**
     * set text page slider text list
     *
     * @param textList text list
     */
    public void setTextList(List<String> textList) {
        TextPageSliderProvider textPageSliderProvider = new TextPageSliderProvider(getContext(), textList);
        pageCount = textPageSliderProvider.getCount();
        textPageSlider.setProvider(textPageSliderProvider);
        textPageSliderProvider.setTextClickedListener((component, textIndex) -> {
            if (textItemClickedListener != null) {
                textItemClickedListener.onTextItemClicked(component, textIndex);
            }
        });
    }

    /**
     * start textPageSliderCard auto play
     *
     * @param interval auto play interval
     */
    public void startAutoPlay(int interval) {
        this.interval = interval;
        getContext().getUITaskDispatcher().delayDispatch(new Runnable() {
            @Override
            public void run() {
                currentPage++;
                if (currentPage == pageCount) {
                    currentPage = 0;
                }
                textPageSlider.setCurrentPage(currentPage);
                if (pageSliderShow) {
                    getContext().getUITaskDispatcher().delayDispatch(this, interval);
                }
            }
        }, interval);
    }

    /**
     * set text more clicked listener
     *
     * @param textMoreClickedListener text more clicked listener
     */
    public void setTextMoreClickedListener(ClickedListener textMoreClickedListener) {
        this.textMoreClickedListener = textMoreClickedListener;
    }

    /**
     * set text item clicked listener
     *
     * @param textItemClickedListener text item clicked listener
     */
    public void setTextItemClickedListener(TextItemClickedListener textItemClickedListener) {
        this.textItemClickedListener = textItemClickedListener;
    }

    /**
     * text item clicked listener
     */
    public interface TextItemClickedListener {
        void onTextItemClicked(Component component, int textIndex);
    }
}
