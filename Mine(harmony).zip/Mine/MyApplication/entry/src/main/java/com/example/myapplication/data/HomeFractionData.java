package com.example.myapplication.data;

import com.example.myapplication.ResourceTable;
import com.example.myapplication.model.GridItem;
import com.example.myapplication.model.InformationItem;
import com.example.myapplication.model.RecommendItem;

import ohos.aafwk.ability.AbilitySlice;
import ohos.agp.colors.RgbColor;
import ohos.agp.utils.Color;
import ohos.global.resource.NotExistException;
import ohos.global.resource.WrongTypeException;
import ohos.hiviewdfx.HiLog;
import ohos.hiviewdfx.HiLogLabel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Home fraction data
 */
public class HomeFractionData {
    private static final HiLogLabel LABEL_LOG = new HiLogLabel(HiLog.DEBUG, 0, "HomeFractionData");

    /**
     * get coreFeaturesContainer data
     *
     * @param slice ability slice
     * @return gridItem list
     */
    public static List<GridItem> getCoreFeaturesContainerData(AbilitySlice slice) {
        List<GridItem> coreFeaturesItemList = new ArrayList<>();
        try {
            coreFeaturesItemList.add(new GridItem(ResourceTable.Media_pay,
                    slice.getResourceManager().getElement(ResourceTable.String_pay).getString(), 1));
            coreFeaturesItemList.add(new GridItem(ResourceTable.Media_gathering,
                    slice.getResourceManager().getElement(ResourceTable.String_gathering).getString(), 2));
            coreFeaturesItemList.add(new GridItem(ResourceTable.Media_transfer,
                    slice.getResourceManager().getElement(ResourceTable.String_transfer).getString(), 3));
            coreFeaturesItemList.add(new GridItem(ResourceTable.Media_account,
                    slice.getResourceManager().getElement(ResourceTable.String_account).getString(), 4));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get core features container data string fail");
        }
        return coreFeaturesItemList;
    }

    /**
     * get featuresContainer data
     *
     * @param slice ability slice
     * @return gridItem list
     */
    public static List<GridItem> getFeaturesContainerData(AbilitySlice slice) {
        List<GridItem> featuresItemList = new ArrayList<>();
        try {
            featuresItemList.add(new GridItem(ResourceTable.Media_borrow,
                    slice.getResourceManager().getElement(ResourceTable.String_borrow).getString(), 0));
            featuresItemList.add(new GridItem(ResourceTable.Media_top_up,
                    slice.getResourceManager().getElement(ResourceTable.String_top_up).getString(), 1));
            featuresItemList.add(new GridItem(ResourceTable.Media_fund,
                    slice.getResourceManager().getElement(ResourceTable.String_fund).getString(), 2));
            featuresItemList.add(new GridItem(ResourceTable.Media_quota,
                    slice.getResourceManager().getElement(ResourceTable.String_quota).getString(), 3));
            featuresItemList.add(new GridItem(ResourceTable.Media_store,
                    slice.getResourceManager().getElement(ResourceTable.String_store).getString(), 4));
            featuresItemList.add(new GridItem(ResourceTable.Media_credit_card,
                    slice.getResourceManager().getElement(ResourceTable.String_credit_card).getString(), 5));
            featuresItemList.add(new GridItem(ResourceTable.Media_transaction_query,
                    slice.getResourceManager().getElement(ResourceTable.String_transaction_query).getString(),
                    6));
            featuresItemList.add(new GridItem(ResourceTable.Media_more,
                    slice.getResourceManager().getElement(ResourceTable.String_more).getString(), 7));

        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get features container data string fail");
        }
        return featuresItemList;
    }

    /**
     * get textPageSliderCard data
     *
     * @param slice ability slice
     * @return text list
     */
    public static List<String> getTextPageSliderCardData(AbilitySlice slice) {
        List<String> textList = new ArrayList<>();
        try {
            textList.add(slice.getResourceManager().getElement(ResourceTable.String_content_one).getString());
            textList.add(slice.getResourceManager().getElement(ResourceTable.String_content_two).getString());
            textList.add(slice.getResourceManager().getElement(ResourceTable.String_content_three).getString());
            textList.add(slice.getResourceManager().getElement(ResourceTable.String_content_four).getString());
            textList.add(slice.getResourceManager().getElement(ResourceTable.String_content_one).getString());
            textList.add(slice.getResourceManager().getElement(ResourceTable.String_content_two).getString());
            textList.add(slice.getResourceManager().getElement(ResourceTable.String_content_three).getString());
            textList.add(slice.getResourceManager().getElement(ResourceTable.String_content_four).getString());
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get text page slider card string fail");
        }
        return textList;
    }

    /**
     * get imagePageSliderCard data
     *
     * @return image list
     */
    public static List<Integer> getImagePageSliderCardData() {
        List<Integer> imageList = new ArrayList<>();
        imageList.add(ResourceTable.Media_home_banner);
        imageList.add(ResourceTable.Media_home_banner);
        imageList.add(ResourceTable.Media_home_banner);
        imageList.add(ResourceTable.Media_home_banner);
        imageList.add(ResourceTable.Media_home_banner);
        return imageList;
    }

    /**
     * get recommendCard title
     *
     * @param slice ability slice
     * @return recommendCard title
     */
    public static String getRecommendCardTitle(AbilitySlice slice) {
        String recommendCardTitle = "";
        try {
            recommendCardTitle = slice.getResourceManager().getElement(ResourceTable.String_recommend).getString();
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get recommend card title string fail");
        }
        return recommendCardTitle;
    }

    /**
     * get recommendCard data
     *
     * @param slice ability slice
     * @return recommendItem list
     */
    public static List<RecommendItem> getRecommendCardData(AbilitySlice slice) {
        List<RecommendItem> recommendItemList = new ArrayList<>();
        try {
            recommendItemList.add(new RecommendItem(ResourceTable.Media_recommend_one,
                    slice.getResourceManager().getElement(ResourceTable.String_recommend_text_one).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_recommend_desc).getString()));
            recommendItemList.add(new RecommendItem(ResourceTable.Media_recommend_two,
                    slice.getResourceManager().getElement(ResourceTable.String_recommend_text_two).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_recommend_desc).getString()));
            recommendItemList.add(new RecommendItem(ResourceTable.Media_recommend_three,
                    slice.getResourceManager().getElement(ResourceTable.String_recommend_text_three).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_recommend_desc).getString()));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get recommend card data string fail");
        }
        return recommendItemList;
    }

    /**
     * get informationCard title
     *
     * @param slice ability slice
     * @return informationCard title
     */
    public static String getInformationCardTitle(AbilitySlice slice) {
        String informationCardTitle = "";
        try {
            informationCardTitle = slice.getResourceManager().getElement(ResourceTable.String_information).getString();
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get information card title string fail");
        }
        return informationCardTitle;
    }

    /**
     * get informationCard data
     *
     * @param slice ability slice
     * @return informationItem list
     */
    public static List<InformationItem> getInformationCardData(AbilitySlice slice) {
        ArrayList<InformationItem> informationItemList = new ArrayList<>();
        try {
            informationItemList.add(new InformationItem(
                    slice.getResourceManager().getElement(ResourceTable.String_information_title_one).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_information_auxiliary_text).getString(),
                    ResourceTable.Media_information_image_one));
            informationItemList.add(new InformationItem(
                    slice.getResourceManager().getElement(ResourceTable.String_information_title_two).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_information_auxiliary_text).getString(),
                    ResourceTable.Media_information_image_two));
            informationItemList.add(new InformationItem(
                    slice.getResourceManager().getElement(ResourceTable.String_information_title_three).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_information_auxiliary_text).getString(),
                    ResourceTable.Media_information_image_three));
            informationItemList.add(new InformationItem(
                    slice.getResourceManager().getElement(ResourceTable.String_information_title_one).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_information_auxiliary_text).getString(),
                    ResourceTable.Media_information_image_one));
            informationItemList.add(new InformationItem(
                    slice.getResourceManager().getElement(ResourceTable.String_information_title_two).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_information_auxiliary_text).getString(),
                    ResourceTable.Media_information_image_two));
            informationItemList.add(new InformationItem(
                    slice.getResourceManager().getElement(ResourceTable.String_information_title_three).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_information_auxiliary_text).getString(),
                    ResourceTable.Media_information_image_three));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get information card string fail");
        }
        return informationItemList;
    }

    /**
     * get searchBar black color
     *
     * @param slice ability slice
     * @return searchBar black color
     */
    public static RgbColor getSearchBarBlackColor(AbilitySlice slice) {
        RgbColor blackColor = null;
        try {
            blackColor = RgbColor.fromArgbInt(Color.getIntColor(
                    slice.getResourceManager().getElement(ResourceTable.Color_search_box_black).getString()));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get search bar color fail");
        }
        return blackColor;
    }
}
