package com.example.myapplication.model;

/**
 * RecommendItem data wrapper class
 */
public class RecommendItem {
    private final int imageId;
    private final String name;
    private final String desc;

    public RecommendItem(int imageId, String name, String desc) {
        this.imageId = imageId;
        this.name = name;
        this.desc = desc;
    }

    public int getImageId() {
        return imageId;
    }

    public String getName() {
        return name;
    }

    public String getDesc() {
        return desc;
    }
}
