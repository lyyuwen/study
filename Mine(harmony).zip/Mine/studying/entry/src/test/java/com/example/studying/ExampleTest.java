package com.example.studying;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
