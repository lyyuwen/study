package com.example.demo1.component;

import com.example.demo1.ResourceTable;
import com.example.demo1.provider.ImagePageSliderProvider;

import ohos.agp.components.Component;
import ohos.agp.components.DirectionalLayout;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.PageSlider;
import ohos.agp.components.PageSliderIndicator;
import ohos.agp.components.AttrSet;
import ohos.agp.components.element.ShapeElement;
import ohos.app.Context;
import ohos.multimodalinput.event.TouchEvent;

import java.util.List;

/**
 * ImagePageSliderCard can be played automatically.
 */
public class ImagePageSliderCard extends DirectionalLayout {
    private PageSlider pageSlider;
    private PageSliderIndicator pageSliderIndicator;

    private int interval = 0;
    private int currentPage = 0;
    private int pageCount = 0;
    private boolean pageSlidePlay = true;
    private boolean pageSliderShow = true;

    private ImageItemClickedListener imageItemClickedListener;

    public ImagePageSliderCard(Context context) {
        super(context);
        initPageSlider();
    }

    public ImagePageSliderCard(Context context, AttrSet attrSet) {
        super(context, attrSet);
        initPageSlider();
    }

    public ImagePageSliderCard(Context context, AttrSet attrSet, String styleName) {
        super(context, attrSet, styleName);
        initPageSlider();
    }

    /**
     * add the created pageSlider to imagePageSlider and add listeners to the pageSlider
     */
    private void initPageSlider() {
        Component imagePageSlider = LayoutScatter.getInstance(
                getContext()).parse(ResourceTable.Layout_image_page_slider_card, null, false);
        this.addComponent(imagePageSlider);

        pageSlider = (PageSlider) imagePageSlider.findComponentById(ResourceTable.Id_page_slider);
        pageSliderIndicator = (PageSliderIndicator) imagePageSlider.findComponentById(
                ResourceTable.Id_page_slider_indicator);

        pageSlider.setCircularModeEnabled(true);
        ShapeElement normalElement = new ShapeElement(getContext(), ResourceTable.Graphic_unselected_page_bg_element);
        ShapeElement selectedElement = new ShapeElement(getContext(), ResourceTable.Graphic_selected_page_bg_element);
        pageSliderIndicator.setItemElement(normalElement, selectedElement);

        pageSlider.setClickedListener((Component component) -> {
            if (imageItemClickedListener != null) {
                imageItemClickedListener.onImageItemClicked(component, currentPage);
            }
        });

        pageSlider.addPageChangedListener(new PageSlider.PageChangedListener() {
            @Override
            public void onPageSliding(int itemPos, float itemPosOffset, int itemPosOffsetPixels) {
            }

            @Override
            public void onPageSlideStateChanged(int state) {
            }

            @Override
            public void onPageChosen(int itemPos) {
                currentPage = itemPos;
            }
        });

        pageSlider.setTouchEventListener((Component component, TouchEvent touchEvent) -> {
            if (touchEvent.getAction() == TouchEvent.PRIMARY_POINT_DOWN) {
                pageSlidePlay = false;
            } else if (touchEvent.getAction() == TouchEvent.PRIMARY_POINT_UP) {
                currentPage--;
                pageSlidePlay = true;
            }
            return true;
        });

        setBindStateChangedListener(new BindStateChangedListener() {
            @Override
            public void onComponentBoundToWindow(Component component) {
                if (!pageSliderShow) {
                    startAutoPlay(interval);
                }
                pageSliderShow = true;
            }

            @Override
            public void onComponentUnboundFromWindow(Component component) {
                pageSliderShow = false;
            }
        });
    }

    /**
     * set image page slider image list
     *
     * @param imageList image list
     */
    public void setImageList(List<Integer> imageList) {
        pageCount = imageList.size();
        ImagePageSliderProvider imagePageSliderProvider = new ImagePageSliderProvider(getContext(), imageList);
        pageSlider.setProvider(imagePageSliderProvider);
        pageSliderIndicator.setPageSlider(pageSlider);
    }

    /**
     * start imagePageSlider auto play
     *
     * @param interval auto play interval
     */
    public void startAutoPlay(int interval) {
        this.interval = interval;
        getContext().getUITaskDispatcher().delayDispatch(new Runnable() {
            @Override
            public void run() {
                if (pageSlidePlay) {
                    currentPage++;
                    if (currentPage == pageCount) {
                        currentPage = 0;
                    }
                    if (currentPage >= 0) {
                        pageSlider.setCurrentPage(currentPage);
                    } else {
                        currentPage = 0;
                    }
                }
                if (pageSliderShow) {
                    getContext().getUITaskDispatcher().delayDispatch(this, interval);
                }
            }
        }, interval);
    }

    /**
     * set image item clicked listener
     *
     * @param imageItemClickedListener image item clicked listener
     */
    public void setImageItemClickedListener(ImageItemClickedListener imageItemClickedListener) {
        this.imageItemClickedListener = imageItemClickedListener;
    }

    /**
     * image item clicked listener
     */
    public interface ImageItemClickedListener {
        void onImageItemClicked(Component component, int index);
    }
}
