package com.example.demo1.provider;

import ohos.agp.components.Component;
import ohos.agp.components.ComponentContainer;
import ohos.agp.components.Image;
import ohos.agp.components.PageSliderProvider;
import ohos.app.Context;

import java.util.List;

/**
 * ImagePageSlider item provider
 */
public class ImagePageSliderProvider extends PageSliderProvider {
    private final Context context;
    private final List<Integer> imageList;

    public ImagePageSliderProvider(Context context, List<Integer> imageList) {
        this.context = context;
        this.imageList = imageList;
    }

    @Override
    public int getCount() {
        if (imageList != null) {
            return imageList.size();
        } else {
            return 0;
        }
    }

    @Override
    public Object createPageInContainer(ComponentContainer componentContainer, int position) {
        Image image = new Image(context);
        image.setWidth(ComponentContainer.LayoutConfig.MATCH_PARENT);
        image.setHeight(ComponentContainer.LayoutConfig.MATCH_PARENT);
        image.setScaleMode(Image.ScaleMode.STRETCH);
        image.setPixelMap(imageList.get(position));
        componentContainer.addComponent(image);
        return image;
    }

    @Override
    public void destroyPageFromContainer(ComponentContainer componentContainer, int position, Object object) {
        if (object instanceof Component) {
            componentContainer.removeComponent((Component) object);
        }
    }

    @Override
    public boolean isPageMatchToObject(Component component, Object object) {
        return true;
    }
}
