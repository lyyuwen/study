package com.example.demo1.model;

/**
 * LikeListContainer data wrapper class
 */
public class LikeItem {
    private final String title;
    private final String desc;
    private final String price;
    private final String sold;
    private final int imageId;

    public LikeItem(String title, String desc, String price, String sold, int imageId) {
        this.title = title;
        this.desc = desc;
        this.price = price;
        this.sold = sold;
        this.imageId = imageId;
    }

    public String getTitle() {
        return title;
    }

    public String getDesc() {
        return desc;
    }

    public String getPrice() {
        return price;
    }

    public String getSold() {
        return sold;
    }

    public int getImageId() {
        return imageId;
    }
}
