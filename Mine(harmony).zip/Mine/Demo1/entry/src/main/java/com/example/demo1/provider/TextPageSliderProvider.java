package com.example.demo1.provider;

import com.example.demo1.ResourceTable;

import ohos.agp.components.Component;
import ohos.agp.components.ComponentContainer;
import ohos.agp.components.DirectionalLayout;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.PageSliderProvider;
import ohos.agp.components.Text;
import ohos.app.Context;

import java.util.List;

/**
 * TextPageSlider item provider
 */
public class TextPageSliderProvider extends PageSliderProvider {
    private static final int TEXT_COUNT_ONE_PAGE = 2;

    private final Context context;
    private final List<String> textList;
    private TextClickedListener textClickedListener;

    public TextPageSliderProvider(Context context, List<String> textList) {
        this.context = context;
        this.textList = textList;
    }

    @Override
    public int getCount() {
        if (textList != null) {
            return textList.size() / TEXT_COUNT_ONE_PAGE + textList.size() % TEXT_COUNT_ONE_PAGE;
        } else {
            return 0;
        }
    }

    @Override
    public Object createPageInContainer(ComponentContainer componentContainer, int index) {
        DirectionalLayout directionalLayout = new DirectionalLayout(context);
        directionalLayout.setWidth(ComponentContainer.LayoutConfig.MATCH_PARENT);
        directionalLayout.setHeight(ComponentContainer.LayoutConfig.MATCH_PARENT);
        directionalLayout.setOrientation(Component.VERTICAL);
        for (int i = index * TEXT_COUNT_ONE_PAGE; i < index * TEXT_COUNT_ONE_PAGE + TEXT_COUNT_ONE_PAGE; i++) {
            Text text = (Text) LayoutScatter.getInstance(context)
                    .parse(ResourceTable.Layout_text_item, null, false);
            text.setText(textList.get(i));
            final int textIndex = i;
            text.setClickedListener((Component component) -> {
                if (textClickedListener != null) {
                    textClickedListener.onTextClicked(component, textIndex);
                }
            });
            directionalLayout.addComponent(text);
        }
        componentContainer.addComponent(directionalLayout);
        return directionalLayout;
    }

    @Override
    public void destroyPageFromContainer(ComponentContainer componentContainer, int position, Object object) {
        if (object instanceof Component) {
            componentContainer.removeComponent((Component) object);
        }
    }

    @Override
    public boolean isPageMatchToObject(Component component, Object object) {
        return true;
    }

    /**
     * set text clicked listener
     *
     * @param textClickedListener text clicked listener
     */
    public void setTextClickedListener(TextClickedListener textClickedListener) {
        this.textClickedListener = textClickedListener;
    }

    /**
     * text clicked listener
     */
    public interface TextClickedListener {
        void onTextClicked(Component component, int textIndex);
    }
}
