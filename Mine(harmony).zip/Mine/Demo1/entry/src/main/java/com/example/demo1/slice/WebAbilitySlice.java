package com.example.demo1.slice;

import com.example.demo1.ResourceTable;

import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import ohos.agp.components.DirectionalLayout;
import ohos.agp.components.Image;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.Text;
import ohos.agp.components.webengine.Navigator;
import ohos.agp.components.webengine.WebAgent;
import ohos.agp.components.webengine.WebConfig;
import ohos.agp.components.webengine.WebView;
import ohos.agp.utils.Color;
import ohos.global.resource.NotExistException;
import ohos.global.resource.WrongTypeException;
import ohos.hiviewdfx.HiLog;
import ohos.hiviewdfx.HiLogLabel;

import java.io.IOException;

/**
 * WebAbilitySlice is used to display web pages, saves the browse record.
 * The back button in the upper left corner allows to go back. If cannot go back, the slice will be terminated.
 * Currently, the local HTML file in the resources/rawfile/pay directory is loaded.
 */
public class WebAbilitySlice extends AbilitySlice {
    private static final HiLogLabel LABEL_LOG = new HiLogLabel(HiLog.DEBUG, 0, "WebAbilitySlice");
    private static final String URL =
            "content://com.example.demo1.dataability/rawfile/pay/index.html";

    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        DirectionalLayout dependentLayout = (DirectionalLayout) LayoutScatter.getInstance(this)
                .parse(ResourceTable.Layout_ability_web, null, false);
        setUIContent(dependentLayout);

        Image back = (Image) findComponentById(ResourceTable.Id_back);
        Text title = (Text) findComponentById(ResourceTable.Id_title);
        WebView webView = (WebView) findComponentById(ResourceTable.Id_webview);

        webView.getWebConfig().setDataAbilityPermit(true);
        webView.getWebConfig().setWebStoragePermit(true);
        webView.getWebConfig().setLocationPermit(true);
        webView.getWebConfig().setLoadsImagesPermit(true);
        webView.getWebConfig().setSecurityMode(WebConfig.SECURITY_SELF_ADAPTIVE);
        webView.getWebConfig().setJavaScriptPermit(true);
        webView.load(URL);

        webView.setWebAgent(new WebAgent() {
            @Override
            public void onPageLoaded(WebView webView, String url) {
                super.onPageLoaded(webView, url);
                title.setText(webView.getTitle());
            }
        });

        title.setText(webView.getTitle());

        Navigator navigator = webView.getNavigator();
        back.setClickedListener(component -> {
            if (navigator.canGoBack()) {
                navigator.goBack();
            } else {
                terminate();
            }
        });
    }

    @Override
    protected void onActive() {
        initBackgroundColor();
    }

    private void initBackgroundColor() {
        try {
            getWindow().setStatusBarColor(Color.getIntColor(getContext()
                    .getResourceManager().getElement(ResourceTable.Color_white_status_bar_background).getString()));
            getWindow().setNavigationBarColor(Color.getIntColor(getContext()
                    .getResourceManager().getElement(ResourceTable.Color_navigation_background).getString()));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get background color fail");
        }
    }
}
