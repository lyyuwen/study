package com.example.demo1.model;

/**
 * GridContainer data wrapper class
 */
public class GridItem {
    private final int identification;
    private final int featureIcon;
    private final String featureText;

    public GridItem(int featureIcon, String featureText, int identification) {
        this.featureIcon = featureIcon;
        this.featureText = featureText;
        this.identification = identification;
    }

    public int getFeatureIcon() {
        return featureIcon;
    }

    public String getFeatureText() {
        return featureText;
    }

    public int getIdentification() {
        return identification;
    }
}
