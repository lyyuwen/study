package com.example.demo1.data;

import com.example.demo1.ResourceTable;
import com.example.demo1.model.FeaturesTabItem;
import com.example.demo1.model.GridItem;

import ohos.aafwk.ability.AbilitySlice;
import ohos.agp.colors.RgbColor;
import ohos.agp.utils.Color;
import ohos.global.resource.NotExistException;
import ohos.global.resource.WrongTypeException;
import ohos.hiviewdfx.HiLog;
import ohos.hiviewdfx.HiLogLabel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * More ability slice data
 */
public class MoreAbilitySliceData {
    private static final HiLogLabel LABEL_LOG = new HiLogLabel(HiLog.DEBUG, 0, "MoreAbilitySliceData");

    /**
     * get myFeaturesContainer data
     *
     * @param slice ability slice
     * @return gridItem list
     */
    public static List<GridItem> getMyFeaturesContainerData(AbilitySlice slice) {
        List<GridItem> myFeaturesItemList = new ArrayList<>();
        try {
            myFeaturesItemList.add(new GridItem(ResourceTable.Media_borrow,
                    slice.getResourceManager().getElement(ResourceTable.String_borrow).getString(), 0));
            myFeaturesItemList.add(new GridItem(ResourceTable.Media_top_up,
                    slice.getResourceManager().getElement(ResourceTable.String_top_up).getString(), 1));
            myFeaturesItemList.add(new GridItem(ResourceTable.Media_fund,
                    slice.getResourceManager().getElement(ResourceTable.String_fund).getString(), 2));
            myFeaturesItemList.add(new GridItem(ResourceTable.Media_quota,
                    slice.getResourceManager().getElement(ResourceTable.String_quota).getString(), 3));
            myFeaturesItemList.add(new GridItem(ResourceTable.Media_store,
                    slice.getResourceManager().getElement(ResourceTable.String_store).getString(), 4));
            myFeaturesItemList.add(new GridItem(ResourceTable.Media_credit_card,
                    slice.getResourceManager().getElement(ResourceTable.String_credit_card).getString(),
                    5));
            myFeaturesItemList.add(new GridItem(ResourceTable.Media_transaction_query,
                    slice.getResourceManager().getElement(ResourceTable.String_transaction_query).getString(),
                    6));
            myFeaturesItemList.add(new GridItem(ResourceTable.Media_invoice,
                    slice.getResourceManager().getElement(ResourceTable.String_invoice).getString(), 7));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get my features container data string fail");
        }
        return myFeaturesItemList;
    }

    /**
     * get tab string list
     *
     * @param slice ability slice
     * @return string list
     */
    public static List<String> getTabStringList(AbilitySlice slice) {
        List<String> tabStringList = new ArrayList<>();
        try {
            tabStringList.add(slice.getResourceManager().getElement(ResourceTable.String_tab_one).getString());
            tabStringList.add(slice.getResourceManager().getElement(ResourceTable.String_tab_two).getString());
            tabStringList.add(slice.getResourceManager().getElement(ResourceTable.String_tab_three).getString());
            tabStringList.add(slice.getResourceManager().getElement(ResourceTable.String_tab_four).getString());
            tabStringList.add(slice.getResourceManager().getElement(ResourceTable.String_tab_five).getString());
            tabStringList.add(slice.getResourceManager().getElement(ResourceTable.String_tab_six).getString());
            tabStringList.add(slice.getResourceManager().getElement(ResourceTable.String_tab_seven).getString());
            tabStringList.add(slice.getResourceManager().getElement(ResourceTable.String_tab_eight).getString());
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get tab list string fail");
        }
        return tabStringList;
    }

    /**
     * get featuresTabListContainer data
     *
     * @param slice ability slice
     * @return featuresTabItem list
     */
    public static List<FeaturesTabItem> getFeaturesTabListContainerData(AbilitySlice slice) {
        List<String> tabStringList = MoreAbilitySliceData.getTabStringList(slice);
        List<FeaturesTabItem> featuresTabItemList = new ArrayList<>();
        for (int i = 0; i < tabStringList.size(); i++) {
            try {
                List<GridItem> gridItemList = new ArrayList<>();
                gridItemList.add(new GridItem(ResourceTable.Media_transportation,
                        slice.getResourceManager().getElement(ResourceTable.String_transportation).getString(),
                        100 * i));
                gridItemList.add(new GridItem(ResourceTable.Media_card_volume,
                        slice.getResourceManager().getElement(ResourceTable.String_card_volume).getString(),
                        100 * i + 1));
                gridItemList.add(new GridItem(ResourceTable.Media_air_ticket,
                        slice.getResourceManager().getElement(ResourceTable.String_air_ticket).getString(),
                        100 * i + 2));
                gridItemList.add(new GridItem(ResourceTable.Media_wisdom_card,
                        slice.getResourceManager().getElement(ResourceTable.String_wisdom_card).getString(),
                        100 * i + 3));
                gridItemList.add(new GridItem(ResourceTable.Media_health_code,
                        slice.getResourceManager().getElement(ResourceTable.String_health_code).getString(),
                        100 * i + 4));
                gridItemList.add(new GridItem(ResourceTable.Media_coin,
                        slice.getResourceManager().getElement(ResourceTable.String_coin).getString(),
                        100 * i + 5));
                gridItemList.add(new GridItem(ResourceTable.Media_hotel,
                        slice.getResourceManager().getElement(ResourceTable.String_hotel).getString(),
                        100 * i + 6));
                gridItemList.add(new GridItem(ResourceTable.Media_holiday,
                        slice.getResourceManager().getElement(ResourceTable.String_holiday).getString(),
                        100 * i + 7));
                featuresTabItemList.add(new FeaturesTabItem(tabStringList.get(i), gridItemList));
            } catch (IOException | NotExistException | WrongTypeException e) {
                HiLog.info(LABEL_LOG, "get features list string fail");
            }
        }
        return featuresTabItemList;
    }

    /**
     * get searchBox background color
     *
     * @param slice ability slice
     * @return searchBox background color
     */
    public static RgbColor getSearchBoxBackgroundColor(AbilitySlice slice) {
        RgbColor searchBoxBackgroundColor = null;
        try {
            searchBoxBackgroundColor = RgbColor.fromArgbInt(Color.getIntColor(
                    slice.getResourceManager().getElement(ResourceTable.Color_search_box_black).getString()));
        } catch (IOException | WrongTypeException | NotExistException e) {
            HiLog.info(LABEL_LOG, "get search bar color fail");
        }
        return searchBoxBackgroundColor;
    }
}
