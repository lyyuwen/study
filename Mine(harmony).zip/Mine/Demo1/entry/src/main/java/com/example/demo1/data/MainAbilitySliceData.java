package com.example.demo1.data;

import com.example.demo1.ResourceTable;
import com.example.demo1.model.NavigationItem;

import ohos.aafwk.ability.AbilitySlice;
import ohos.agp.utils.Color;
import ohos.global.resource.NotExistException;
import ohos.global.resource.WrongTypeException;
import ohos.hiviewdfx.HiLog;
import ohos.hiviewdfx.HiLogLabel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Main ability slice data
 */
public class MainAbilitySliceData {
    private static final HiLogLabel LABEL_LOG = new HiLogLabel(HiLog.DEBUG, 0, "MainAbilitySliceData");

    /**
     * get navigationItem list
     *
     * @param slice ability slice
     * @return navigationItem list
     */
    public static List<NavigationItem> getNavigationItemList(AbilitySlice slice) {
        List<NavigationItem> navigationItemList = new ArrayList<>();
        try {
            navigationItemList.add(new NavigationItem(ResourceTable.Media_main,
                    ResourceTable.Media_main_click,
                    slice.getResourceManager().getElement(ResourceTable.String_home).getString()));
            navigationItemList.add(new NavigationItem(ResourceTable.Media_life,
                    ResourceTable.Media_life_click,
                    slice.getResourceManager().getElement(ResourceTable.String_life).getString()));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get navigation item string fail");
        }
        return navigationItemList;
    }

    /**
     * get navigationBar normal text color
     *
     * @param slice ability slice
     * @return navigationBar normal text color
     */
    public static Color getNormalTextColor(AbilitySlice slice) {
        Color normalTextColor = null;
        try {
            normalTextColor = new Color(Color.getIntColor(
                    slice.getResourceManager().getElement(ResourceTable.Color_navigation_unselected).getString()));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get normal text color fail");
        }
        return normalTextColor;
    }

    /**
     * get navigationBar selected text color
     *
     * @param slice ability slice
     * @return navigationBar selected text color
     */
    public static Color getSelectedTextColor(AbilitySlice slice) {
        Color selectedTextColor = null;
        try {
            selectedTextColor = new Color(Color.getIntColor(
                    slice.getResourceManager().getElement(ResourceTable.Color_navigation_selected).getString()));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get selected text color fail");
        }
        return selectedTextColor;
    }
}
