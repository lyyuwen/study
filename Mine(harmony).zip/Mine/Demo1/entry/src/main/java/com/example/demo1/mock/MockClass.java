package com.example.demo1.mock;


import com.example.demo1.component.ImagePageSliderCard;
import com.example.demo1.component.TextPageSliderCard;
import com.huawei.asm.core.PreviewerMock;
import com.huawei.asm.core.annotation.PreviewerMockMethod;

public class MockClass extends PreviewerMock {
    @PreviewerMockMethod
    public void startAutoPlay(TextPageSliderCard textPageSliderCard, int interval) {
        return;
    }

    @PreviewerMockMethod
    public void startAutoPlay(ImagePageSliderCard imagePageSliderCard, int interval) {
        return;
    }
}
