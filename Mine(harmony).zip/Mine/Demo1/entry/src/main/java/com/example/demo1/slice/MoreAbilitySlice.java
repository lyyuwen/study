package com.example.demo1.slice;

import com.example.demo1.ResourceTable;
import com.example.demo1.component.SearchBox;
import com.example.demo1.component.GridContainer;
import com.example.demo1.data.MoreAbilitySliceData;
import com.example.demo1.model.GridItem;
import com.example.demo1.provider.FeaturesTabListProvider;

import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import ohos.agp.colors.RgbColor;
import ohos.agp.components.AttrHelper;
import ohos.agp.components.Component;
import ohos.agp.components.ComponentContainer;
import ohos.agp.components.DependentLayout;
import ohos.agp.components.DirectionalLayout;
import ohos.agp.components.DragInfo;
import ohos.agp.components.Image;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.ListContainer;
import ohos.agp.components.ScrollView;
import ohos.agp.components.TabList;
import ohos.agp.components.TableLayout;
import ohos.agp.components.Text;
import ohos.agp.components.element.ShapeElement;
import ohos.agp.utils.Color;
import ohos.agp.utils.Point;
import ohos.agp.window.service.Display;
import ohos.agp.window.service.DisplayManager;
import ohos.app.Context;
import ohos.global.resource.NotExistException;
import ohos.global.resource.WrongTypeException;
import ohos.hiviewdfx.HiLog;
import ohos.hiviewdfx.HiLogLabel;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import static ohos.agp.components.Component.INVISIBLE;
import static ohos.agp.components.Component.VISIBLE;

/**
 * More ability slice display my features and all features and edit items in my features.
 * Delete items or select items from all features to add them to my features.
 * All the data is in {@link MoreAbilitySliceData}.
 */
public class MoreAbilitySlice extends AbilitySlice {
    private static final HiLogLabel LABEL_LOG = new HiLogLabel(HiLog.DEBUG, 0, "MoreAbilitySlice");
    private static final int HIGH_PRIORITY = 3;
    private static final int MEDIUM_PRIORITY = 2;
    private static final int LOW_PRIORITY = 1;
    private static final int GRID_ITEM_MARGIN_BOTTOM = 12;
    private static final int TAB_TEXT_SIZE = 16;
    private static final int TAB_MARGIN = 16;

    private ScrollView scrollView;
    private DirectionalLayout globalDirectionalLayout;

    private Text guidText;
    private GridContainer myFeaturesContainer;
    private TabList tabList;
    private ListContainer featuresTabListContainer;
    private FeaturesTabListProvider featuresTabListProvider;

    private DirectionalLayout searchBar;
    private Image backImage;
    private Image editImage;

    private boolean isOperableMode = false;
    private int currentTabIndex = 0;
    private boolean featuresTabListContainerScroll = false;
    private boolean tabListScroll = false;
    private boolean scrollViewDragPreAccept = false;

    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        DependentLayout dependentLayout = (DependentLayout) LayoutScatter.getInstance(this)
                .parse(ResourceTable.Layout_ability_more, null, false);
        setUIContent(dependentLayout);

        guidText = (Text) findComponentById(ResourceTable.Id_guid_text);
        featuresTabListContainer = (ListContainer) findComponentById(ResourceTable.Id_features_list_container);

        initSearchBar();
        initScrollView();
        initMyFeatures();
        initTabList();
        initFeaturesListContainer();
    }

    @Override
    protected void onActive() {
        initBackgroundColor();
    }

    private void initBackgroundColor() {
        try {
            getWindow().setStatusBarColor(Color.getIntColor(getContext()
                    .getResourceManager().getElement(ResourceTable.Color_white_status_bar_background).getString()));
            getWindow().setNavigationBarColor(Color.getIntColor(getContext()
                    .getResourceManager().getElement(ResourceTable.Color_navigation_background).getString()));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get background color fail");
        }
    }

    /**
     * When scrollView nested featuresTabListContainer, compare the gesture priorities of the scrollView and
     * featuresTabListContainer to determine whether to slide the scrollView or featuresTabListContainer.
     * When the scrollView slides to the bottom, the gesture priority of the featuresTabListContainer
     * is set to be higher than that of the scrollView, and the featuresTabListContainer starts to slide.
     * Also set the vertical DraggedListener for the scrollView, the onDragPreAccept method returns true
     * so that the scrollView cannot be scrolled.
     * When the featuresTabListContainer slides to the top, the gesture priority of the scrollView is
     * set to be higher than that of the featuresTabListContainer, and the scrollView starts to slide.
     */
    private void initScrollView() {
        scrollView = (ScrollView) findComponentById(ResourceTable.Id_scroll_view);
        globalDirectionalLayout = (DirectionalLayout) findComponentById(ResourceTable.Id_global_directional_layout);

        scrollView.setGesturePriority(Component.GestureType.VERTICAL_DRAG, MEDIUM_PRIORITY);
        scrollView.setScrolledListener((Component component,
                                        int scrollX, int scrollY, int oldScrollX, int oldScrollY) -> {
            if (-globalDirectionalLayout.getTop() >= tabList.getTop() - searchBar.getHeight()) {
                featuresTabListContainer.setGesturePriority(Component.GestureType.VERTICAL_DRAG, HIGH_PRIORITY);
                scrollView.setDraggedListener(Component.DRAG_VERTICAL, new Component.DraggedListener() {
                    @Override
                    public void onDragDown(Component component, DragInfo dragInfo) {
                    }

                    @Override
                    public void onDragStart(Component component, DragInfo dragInfo) {
                    }

                    @Override
                    public void onDragUpdate(Component component, DragInfo dragInfo) {
                    }

                    @Override
                    public void onDragEnd(Component component, DragInfo dragInfo) {
                    }

                    @Override
                    public void onDragCancel(Component component, DragInfo dragInfo) {
                    }

                    @Override
                    public boolean onDragPreAccept(Component component, int dragDirection) {
                        return scrollViewDragPreAccept;
                    }
                });
            } else {
                scrollView.setDraggedListener(Component.DRAG_VERTICAL, null);
                featuresTabListContainer.setGesturePriority(Component.GestureType.VERTICAL_DRAG, LOW_PRIORITY);
            }
        });
    }

    private void initMyFeatures() {
        myFeaturesContainer = new GridContainer((TableLayout) findComponentById(
                ResourceTable.Id_my_features_container));
        myFeaturesContainer.setItemMarginBottom(GRID_ITEM_MARGIN_BOTTOM);
        myFeaturesContainer.setGridItemList(MoreAbilitySliceData.getMyFeaturesContainerData(this));
    }

    /**
     * The tabList can be associated with the featuresTabListContainer.
     * When click an item in the tabList, the featuresTabListContainer slides to the corresponding position.
     * When slide the featuresTabListContainer, the tabList also slide to the corresponding position.
     * The tabList and featuresTabListContainer are associated. Therefore, the tabList and featuresTabListContainer
     * interact with each other during the sliding process, causing frame freezing.
     * Therefore, the tabListScroll and featuresTabListContainerScroll variables are used to mask this effect.
     * When click an item in the tabList, the featuresTabListContainer slides,
     * but the featuresTabListContainer slide does not affect the tabList.
     * When slide the featuresTabListContainer, the tabList slides,
     * but the tabList slide does not affect the featuresTabListContainer.
     */
    private void initTabList() {
        tabList = (TabList) findComponentById(ResourceTable.Id_tab_list);

        List<String> tabStringList = MoreAbilitySliceData.getTabStringList(this);
        for (String tabString : tabStringList) {
            TabList.Tab tab = tabList.new Tab(getContext());
            tab.setText(tabString);
            tabList.addTab(tab);
        }
        tabList.setTabTextSize(AttrHelper.vp2px(TAB_TEXT_SIZE, getContext()));
        tabList.setTabLength(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        tabList.setTabMargin(AttrHelper.vp2px(TAB_MARGIN, getContext()));
        tabList.addTabSelectedListener(new TabList.TabSelectedListener() {
            @Override
            public void onSelected(TabList.Tab tab) {
                if (!featuresTabListContainerScroll) {
                    tabListScroll = true;
                    tabListScrollTo(tabList.getSelectedTabIndex());
                    scrollView.fluentScrollByY(tabList.getTop() - searchBar.getHeight());
                    featuresTabListContainer.scrollTo(tabList.getSelectedTabIndex());
                }
            }

            @Override
            public void onUnselected(TabList.Tab tab) {
            }

            @Override
            public void onReselected(TabList.Tab tab) {
            }
        });
        tabList.selectTabAt(0);
    }

    /**
     * Slide the tabList to the specified position, in order to the selected item in the tabList is located in the
     * center, when the current tab index is 0 or the last position, the tabList has one less slide width.
     *
     * @param index tabList item index
     */
    private void tabListScrollTo(int index) {
        if (index == currentTabIndex || index >= tabList.getTabCount()) {
            return;
        }
        tabList.selectTabAt(index);
        if (index > currentTabIndex) {
            if (currentTabIndex == 0) {
                currentTabIndex = 1;
            }
            int widthCount = 0;
            for (int i = currentTabIndex; i < index; i++) {
                widthCount = widthCount + tabList.getTabAt(i).getWidth();
            }
            tabList.fluentScrollByX(widthCount);
        } else {
            if (currentTabIndex == tabList.getTabCount() - 1) {
                currentTabIndex = tabList.getTabCount() - 2;
            }
            int widthCount = 0;
            for (int i = index; i < currentTabIndex; i++) {
                widthCount = widthCount + tabList.getTabAt(i).getWidth();
            }
            tabList.fluentScrollByX(-widthCount);
        }
        if (index == 0) {
            tabList.fluentScrollXTo(0);
        }
        if (index == tabList.getTabCount() - 1) {
            int widthCount = 0;
            for (int i = 0; i < tabList.getTabCount(); i++) {
                widthCount = widthCount + tabList.getTabAt(i).getWidth();
            }
            tabList.fluentScrollXTo(widthCount);
        }
        currentTabIndex = index;
    }

    /**
     * The featuresTabListContainer and tabList are associated, when featuresTabListContainer slides,
     * the tabList selects the index of featuresTabListContainer displayed the first item.
     */
    private void initFeaturesListContainer() {
        featuresTabListProvider = new FeaturesTabListProvider(this,
                MoreAbilitySliceData.getFeaturesTabListContainerData(this));
        featuresTabListContainer.setItemProvider(featuresTabListProvider);
        featuresTabListContainer.setHeight(getScreenHeight(getContext()) - tabList.getHeight() - searchBar.getHeight());
        featuresTabListContainer.setGesturePriority(Component.GestureType.VERTICAL_DRAG, LOW_PRIORITY);
        featuresTabListContainer.setScrolledListener((Component component,
                                                      int scrollX, int scrollY, int oldScrollX, int oldScrollY) -> {
            if (!tabListScroll) {
                featuresTabListContainerScroll = true;
                tabListScrollTo(featuresTabListContainer.getItemPosByVisibleIndex(0));
                featuresTabListContainerScroll = false;
                tabListScroll = true;
            }
            if (featuresTabListContainer.getItemPosByVisibleIndex(0) == currentTabIndex) {
                tabListScroll = false;
            }
            if (scrollY == 0 && oldScrollY > 0) {
                featuresTabListContainer.setGesturePriority(Component.GestureType.VERTICAL_DRAG, LOW_PRIORITY);
                scrollViewDragPreAccept = false;
            } else {
                featuresTabListContainer.setGesturePriority(Component.GestureType.VERTICAL_DRAG, HIGH_PRIORITY);
                scrollViewDragPreAccept = true;
            }
        });
    }

    private int getScreenHeight(Context context) {
        int screenHeight = 0;
        DisplayManager displayManager = DisplayManager.getInstance();
        Optional<Display> optDisplay = displayManager.getDefaultDisplay(context);
        if (optDisplay.isPresent()) {
            Point point = new Point(0, 0);
            optDisplay.get().getSize(point);
            screenHeight = (int) point.position[1];
        }
        return screenHeight;
    }

    private void initSearchBar() {
        searchBar = (DirectionalLayout) findComponentById(ResourceTable.Id_search_bar);
        SearchBox searchBox = (SearchBox) searchBar.findComponentById(ResourceTable.Id_search_box);
        backImage = (Image) searchBar.findComponentById(ResourceTable.Id_back_image);
        editImage = (Image) searchBar.findComponentById(ResourceTable.Id_edit_image);

        ShapeElement shapeElement = new ShapeElement();
        shapeElement.setRgbColor(RgbColor.fromArgbInt(Color.WHITE.getValue()));
        searchBar.setBackground(shapeElement);
        searchBox.setEnabled(false);
        searchBox.setBackgroundColor(MoreAbilitySliceData.getSearchBoxBackgroundColor(this));

        setBackImageClickedListener();
        setEditImageClickedListener();
    }

    private void setBackImageClickedListener() {
        backImage.setClickedListener((Component component) -> terminate());
    }

    /**
     * When isOperableMode is true, set the operate type of myFeaturesContainer to REMOVE_TYPE,
     * set the operate type of featuresTabListContainer to ADD_TYPE.
     * Add the listener for deleting myFeaturesContainer items, when an item is deleted from myFeaturesContainer,
     * the status of the item in the featuresTabListContainer is changed.
     * Add the listener for adding featuresTabListContainer items,
     * when item addition is clicked, add in myFeaturesContainer.
     */
    private void setEditImageClickedListener() {
        editImage.setClickedListener((Component component) -> {
            myFeaturesContainer.setItemDrag(!isOperableMode);
            guidText.setVisibility(!isOperableMode ? VISIBLE : INVISIBLE);
            if (!isOperableMode) {
                myFeaturesContainer.setOperateType(GridContainer.REMOVE_TYPE);
                featuresTabListProvider.setOperateType(GridContainer.ADD_TYPE);
                editImage.setPixelMap(ResourceTable.Media_ok);
                backImage.setPixelMap(ResourceTable.Media_cancel);
            } else {
                myFeaturesContainer.setOperateType(GridContainer.NONE_TYPE);
                featuresTabListProvider.setOperateType(GridContainer.NONE_TYPE);
                editImage.setPixelMap(ResourceTable.Media_edit);
                backImage.setPixelMap(ResourceTable.Media_back);
            }
            for (int i = 0; i < myFeaturesContainer.getGridItemList().size(); i++) {
                featuresTabListProvider.updateGridContainer(myFeaturesContainer.getGridItemList().get(i),
                        GridContainer.NONE_TYPE);
            }
            myFeaturesContainer.setRemoveClickedListener((GridItem gridItem) ->
                    featuresTabListProvider.updateGridContainer(gridItem, GridContainer.ADD_TYPE)
            );
            featuresTabListProvider.setAddClickedListener((GridItem gridItem) -> {
                boolean addSuccess = myFeaturesContainer.addToContainer(gridItem);
                myFeaturesContainer.setOperateType(GridContainer.REMOVE_TYPE);
                return addSuccess;
            });
            isOperableMode = !isOperableMode;
        });
    }
}