package com.example.demo1.component;

import com.example.demo1.ResourceTable;
import com.example.demo1.model.LikeItem;
import com.example.demo1.provider.LikeListProvider;

import ohos.agp.components.AttrSet;
import ohos.agp.components.Component;
import ohos.agp.components.DirectionalLayout;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.ListContainer;
import ohos.agp.components.ListContainer.ItemClickedListener;
import ohos.agp.components.Text;
import ohos.app.Context;

import java.util.List;

/**
 * LikeCard
 */
public class LikeCard extends DirectionalLayout {
    private Text likeTitle;
    private ListContainer likeList;

    private ClickedListener likeMoreClickedListener;
    private ItemClickedListener likeListItemClickedListener;

    public LikeCard(Context context) {
        super(context);
        initLikeCard();
    }

    public LikeCard(Context context, AttrSet attrSet) {
        super(context, attrSet);
        initLikeCard();
    }

    public LikeCard(Context context, AttrSet attrSet, String styleName) {
        super(context, attrSet, styleName);
        initLikeCard();
    }

    private void initLikeCard() {
        Component likeCard = LayoutScatter.getInstance(
                getContext()).parse(ResourceTable.Layout_like_card, null, false);
        this.addComponent(likeCard);

        likeTitle = (Text) likeCard.findComponentById(ResourceTable.Id_like_title);
        DirectionalLayout likeMore = (DirectionalLayout) likeCard.findComponentById(ResourceTable.Id_like_more);
        likeList = (ListContainer) likeCard.findComponentById(ResourceTable.Id_like_list);

        likeMore.setClickedListener(component -> {
            if (likeMoreClickedListener != null) {
                likeMoreClickedListener.onClick(component);
            }
        });

        likeList.setItemClickedListener((listContainer, component, index, len) -> {
            if (likeListItemClickedListener != null) {
                likeListItemClickedListener.onItemClicked(likeList, listContainer, index, len);
            }
        });
    }

    /**
     * set like card title
     *
     * @param likeTitleText like card title
     */
    public void setLikeTitle(String likeTitleText) {
        likeTitle.setText(likeTitleText);
    }

    /**
     * set like item list
     *
     * @param likeItemList like item list
     */
    public void setLikeItemList(List<LikeItem> likeItemList) {
        LikeListProvider likeListProvider =
                new LikeListProvider(getContext(), likeItemList);
        likeList.setItemProvider(likeListProvider);
    }

    public void setLikeMoreClickedListener(ClickedListener likeMoreClickedListener) {
        this.likeMoreClickedListener = likeMoreClickedListener;
    }

    public void setLikeListItemClickedListener(ItemClickedListener likeListItemClickedListener) {
        this.likeListItemClickedListener = likeListItemClickedListener;
    }
}
