package com.example.demo1.model;

/**
 * InformationListContainer data wrapper class
 */
public class InformationItem {
    private final String title;
    private final String desc;
    private final int imageId;

    public InformationItem(String title, String desc, int imageId) {
        this.title = title;
        this.desc = desc;
        this.imageId = imageId;
    }

    public String getTitle() {
        return title;
    }

    public String getDesc() {
        return desc;
    }

    public int getImageId() {
        return imageId;
    }
}
