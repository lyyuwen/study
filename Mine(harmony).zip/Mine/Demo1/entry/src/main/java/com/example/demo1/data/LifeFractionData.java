package com.example.demo1.data;

import com.example.demo1.ResourceTable;
import com.example.demo1.model.GridItem;
import com.example.demo1.model.LikeItem;
import com.example.demo1.model.RecommendItem;

import ohos.aafwk.ability.AbilitySlice;
import ohos.agp.colors.RgbColor;
import ohos.agp.utils.Color;
import ohos.global.resource.NotExistException;
import ohos.global.resource.WrongTypeException;
import ohos.hiviewdfx.HiLog;
import ohos.hiviewdfx.HiLogLabel;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Life fraction data
 */
public class LifeFractionData {
    private static final HiLogLabel LABEL_LOG = new HiLogLabel(HiLog.DEBUG, 0, "LifeFractionData");

    /**
     * get top imagePageSliderCard data
     *
     * @return image list
     */
    public static List<Integer> getTopImagePageSliderCardData() {
        List<Integer> imageList = new ArrayList<>();
        imageList.add(ResourceTable.Media_life_banner);
        imageList.add(ResourceTable.Media_life_banner);
        imageList.add(ResourceTable.Media_life_banner);
        imageList.add(ResourceTable.Media_life_banner);
        imageList.add(ResourceTable.Media_life_banner);
        return imageList;
    }

    /**
     * get featuresContainer data
     *
     * @param slice ability slice
     * @return gridItem list
     */
    public static List<GridItem> getFeaturesContainerData(AbilitySlice slice) {
        List<GridItem> featuresItemList = new ArrayList<>();
        try {
            featuresItemList.add(new GridItem(ResourceTable.Media_invoice,
                    slice.getResourceManager().getElement(ResourceTable.String_invoice).getString(), 0));
            featuresItemList.add(new GridItem(ResourceTable.Media_transportation,
                    slice.getResourceManager().getElement(ResourceTable.String_transportation).getString(), 1));
            featuresItemList.add(new GridItem(ResourceTable.Media_card_volume,
                    slice.getResourceManager().getElement(ResourceTable.String_card_volume).getString(), 2));
            featuresItemList.add(new GridItem(ResourceTable.Media_air_ticket,
                    slice.getResourceManager().getElement(ResourceTable.String_air_ticket).getString(), 3));
            featuresItemList.add(new GridItem(ResourceTable.Media_wisdom_card,
                    slice.getResourceManager().getElement(ResourceTable.String_wisdom_card).getString(), 4));
            featuresItemList.add(new GridItem(ResourceTable.Media_health_code,
                    slice.getResourceManager().getElement(ResourceTable.String_health_code).getString(), 5));
            featuresItemList.add(new GridItem(ResourceTable.Media_coin,
                    slice.getResourceManager().getElement(ResourceTable.String_coin).getString(), 6));
            featuresItemList.add(new GridItem(ResourceTable.Media_hotel,
                    slice.getResourceManager().getElement(ResourceTable.String_hotel).getString(), 7));
            featuresItemList.add(new GridItem(ResourceTable.Media_holiday,
                    slice.getResourceManager().getElement(ResourceTable.String_holiday).getString(), 8));
            featuresItemList.add(new GridItem(ResourceTable.Media_more,
                    slice.getResourceManager().getElement(ResourceTable.String_more).getString(), 9));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get features container string fail");
        }
        return featuresItemList;
    }

    /**
     * get imagePageSliderCard data
     *
     * @return image list
     */
    public static List<Integer> getImagePageSliderCardData() {
        List<Integer> imageList = new ArrayList<>();
        imageList.add(ResourceTable.Media_home_banner);
        imageList.add(ResourceTable.Media_home_banner);
        imageList.add(ResourceTable.Media_home_banner);
        imageList.add(ResourceTable.Media_home_banner);
        imageList.add(ResourceTable.Media_home_banner);
        return imageList;
    }

    /**
     * get recommendCard title
     *
     * @param slice ability slice
     * @return recommendCard title
     */
    public static String getRecommendCardTitle(AbilitySlice slice) {
        String recommendCardTitle = "";
        try {
            recommendCardTitle = slice.getResourceManager().getElement(ResourceTable.String_guide).getString();
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get recommend card title string fail");
        }
        return recommendCardTitle;
    }

    /**
     * get recommendCard data
     *
     * @param slice ability slice
     * @return recommendItem list
     */
    public static List<RecommendItem> getRecommendCardData(AbilitySlice slice) {
        List<RecommendItem> recommendItemList = new ArrayList<>();
        try {
            recommendItemList.add(new RecommendItem(ResourceTable.Media_guide_one,
                    slice.getResourceManager().getElement(ResourceTable.String_guide_text_one).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_recommend_desc).getString()));
            recommendItemList.add(new RecommendItem(ResourceTable.Media_guide_two,
                    slice.getResourceManager().getElement(ResourceTable.String_guide_text_two).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_recommend_desc).getString()));
            recommendItemList.add(new RecommendItem(ResourceTable.Media_guide_three,
                    slice.getResourceManager().getElement(ResourceTable.String_guide_text_three).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_recommend_desc).getString()));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get recommend card data string fail");
        }
        return recommendItemList;
    }

    /**
     * get likeCard title
     *
     * @param slice ability slice
     * @return likeCard title
     */
    public static String getLikeCardTitle(AbilitySlice slice) {
        String likeCardTitle = "";
        try {
            likeCardTitle = slice.getResourceManager().getElement(ResourceTable.String_guess_you_like).getString();
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get like card title string fail");
        }
        return likeCardTitle;
    }

    /**
     * get likeCard data
     *
     * @param slice ability slice
     * @return likeItem list
     */
    public static List<LikeItem> getLikeCardData(AbilitySlice slice) {
        ArrayList<LikeItem> likeItemList = new ArrayList<>();
        try {
            likeItemList.add(new LikeItem(
                    slice.getResourceManager().getElement(ResourceTable.String_like_title_one).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_like_auxiliary_text).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_price).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_sold).getString(),
                    ResourceTable.Media_like_one));
            likeItemList.add(new LikeItem(
                    slice.getResourceManager().getElement(ResourceTable.String_like_title_two).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_like_auxiliary_text).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_price).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_sold).getString(),
                    ResourceTable.Media_like_two));
            likeItemList.add(new LikeItem(
                    slice.getResourceManager().getElement(ResourceTable.String_like_title_three).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_like_auxiliary_text).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_price).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_sold).getString(),
                    ResourceTable.Media_like_three));
            likeItemList.add(new LikeItem(
                    slice.getResourceManager().getElement(ResourceTable.String_like_title_one).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_like_auxiliary_text).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_price).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_sold).getString(),
                    ResourceTable.Media_like_one));
            likeItemList.add(new LikeItem(
                    slice.getResourceManager().getElement(ResourceTable.String_like_title_two).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_like_auxiliary_text).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_price).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_sold).getString(),
                    ResourceTable.Media_like_two));
            likeItemList.add(new LikeItem(
                    slice.getResourceManager().getElement(ResourceTable.String_like_title_three).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_like_auxiliary_text).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_price).getString(),
                    slice.getResourceManager().getElement(ResourceTable.String_sold).getString(),
                    ResourceTable.Media_like_three));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get like card data string fail");
        }
        return likeItemList;
    }

    /**
     * get searchBar black color
     *
     * @param slice ability slice
     * @return searchBar black color
     */
    public static RgbColor getSearchBarBlackColor(AbilitySlice slice) {
        RgbColor blackColor = null;
        try {
            blackColor = RgbColor.fromArgbInt(Color.getIntColor(
                    slice.getResourceManager().getElement(ResourceTable.Color_search_box_black).getString()));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get search bar color fail");
        }
        return blackColor;
    }

    /**
     * get searchBar text black color
     *
     * @param slice ability slice
     * @return searchBar text black color
     */
    public static Color getSearchBarTextBlackColor(AbilitySlice slice) {
        Color textBlackColor = null;
        try {
            textBlackColor = new Color(Color.getIntColor(
                    slice.getResourceManager().getElement(ResourceTable.Color_normal_text).getString()));
        } catch (IOException | NotExistException | WrongTypeException e) {
            HiLog.info(LABEL_LOG, "get search bar text color fail");
        }
        return textBlackColor;
    }
}
