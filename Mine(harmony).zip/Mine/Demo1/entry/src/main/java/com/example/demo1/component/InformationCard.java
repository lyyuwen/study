package com.example.demo1.component;

import com.example.demo1.ResourceTable;
import com.example.demo1.model.InformationItem;

import com.example.demo1.provider.InformationListProvider;

import ohos.agp.components.AttrSet;
import ohos.agp.components.Component;
import ohos.agp.components.DirectionalLayout;
import ohos.agp.components.LayoutScatter;
import ohos.agp.components.ListContainer;
import ohos.agp.components.ListContainer.ItemClickedListener;
import ohos.agp.components.Text;
import ohos.app.Context;

import java.util.List;

/**
 * InformationCard
 */
public class InformationCard extends DirectionalLayout {
    private Text informationTitle;
    private ListContainer informationList;

    private ClickedListener informationMoreClickedListener;
    private ListContainer.ItemClickedListener informationListItemClickedListener;

    public InformationCard(Context context) {
        super(context);
        initInformationCard();
    }

    public InformationCard(Context context, AttrSet attrSet) {
        super(context, attrSet);
        initInformationCard();
    }

    public InformationCard(Context context, AttrSet attrSet, String styleName) {
        super(context, attrSet, styleName);
        initInformationCard();
    }

    private void initInformationCard() {
        Component informationCard = LayoutScatter.getInstance(
                getContext()).parse(ResourceTable.Layout_information_card, null, false);
        this.addComponent(informationCard);

        informationTitle = (Text) informationCard.findComponentById(ResourceTable.Id_information_title);
        DirectionalLayout informationMore = (DirectionalLayout) informationCard.findComponentById(
                ResourceTable.Id_information_more);
        informationList = (ListContainer) informationCard.findComponentById(ResourceTable.Id_information_list);

        informationMore.setClickedListener(component -> {
            if (informationMoreClickedListener != null) {
                informationMoreClickedListener.onClick(component);
            }
        });

        informationList.setItemClickedListener((listContainer, component, index, len) -> {
            if (informationListItemClickedListener != null) {
                informationListItemClickedListener.onItemClicked(informationList, listContainer, index, len);
            }
        });
    }

    /**
     * set information card title
     *
     * @param informationTitleText information card title
     */
    public void setInformationTitle(String informationTitleText) {
        informationTitle.setText(informationTitleText);
    }

    /**
     * set information item list
     *
     * @param informationItemList information item list
     */
    public void setInformationItemList(List<InformationItem> informationItemList) {
        InformationListProvider informationListProvider =
                new InformationListProvider(getContext(), informationItemList);
        informationList.setItemProvider(informationListProvider);
    }

    public void setInformationMoreClickedListener(ClickedListener informationMoreClickedListener) {
        this.informationMoreClickedListener = informationMoreClickedListener;
    }

    public void setInformationListItemClickedListener(ItemClickedListener informationListItemClickedListener) {
        this.informationListItemClickedListener = informationListItemClickedListener;
    }
}
