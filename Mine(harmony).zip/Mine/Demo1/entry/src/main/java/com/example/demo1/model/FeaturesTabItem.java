package com.example.demo1.model;

import java.util.List;

/**
 * FeaturesTabListContainer data wrapper class
 */
public class FeaturesTabItem {
    private final String title;
    private final List<GridItem> gridItemList;

    public FeaturesTabItem(String title, List<GridItem> gridItemList) {
        this.title = title;
        this.gridItemList = gridItemList;
    }

    public String getTitle() {
        return title;
    }

    public List<GridItem> getGridItemList() {
        return gridItemList;
    }
}
