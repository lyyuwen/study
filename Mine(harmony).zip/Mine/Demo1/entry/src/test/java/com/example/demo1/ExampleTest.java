package com.example.demo1;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
