package com.example.myapp2nd;

import com.example.myapp2nd.slice.MainAbilitySlice;
import ohos.aafwk.ability.Ability;
import ohos.aafwk.content.Intent;

public class MainAbility extends Ability {
    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setMainRoute(MainAbilitySlice.class.getName());
    }
}
class Prog {
    int a1 = 2;
    int a2 = 3;


    public static void main(String args[]) {
        Prog j = new Prog();
        int a3 = j.a1 + j.a2;
        System.out.println(a3);
    }
}