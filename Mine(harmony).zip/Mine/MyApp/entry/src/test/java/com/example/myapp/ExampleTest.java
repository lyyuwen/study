package com.example.myapp;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
